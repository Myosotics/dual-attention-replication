# AIA 替代指标：Cboe 指数期权异常成交量

状态：**真实公开源数据构造的替代代理**，并非原论文 Bloomberg DMR AIA。

已有 `AIA_option_proxy.csv`，可直接按 `date` 合并。源文件是 `indexpc.csv`。若需重建，在本文件夹运行：

```bash
python3 build_AIA_option_proxy.py
```

需要父目录 `ARA.csv` 作为交易日历。脚本仅用 Python 标准库；若源 CSV 已在本文件夹，无须联网。详细定义、来源、覆盖日期和限制见原有中文指标说明 TXT。

当前输出：2,437 行，2010-02-01 至 2019-10-04。缺少 2019 年最后一段，不能称为论文 AIA 的精确复现。
