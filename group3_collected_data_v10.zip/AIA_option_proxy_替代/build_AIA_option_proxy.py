#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""构造 Cboe 指数期权异常成交量代理指标（非论文原始 Bloomberg AIA）。

目录结构：
    data/
    ├── ARA.csv                       # 作者的 ARA：交易日历，绝不修改
    └── AIA_option_proxy/
        ├── build_AIA_option_proxy.py  # 本脚本
        ├── indexpc.csv                # Cboe 官方历史指数期权成交量
        └── AIA_option_proxy.csv       # 唯一结果文件：仅有效观测

运行（在任意工作目录均可）：
    python3 build_AIA_option_proxy.py

公式：aia_option_proxy[t] = Total[t] / median(Total[t-30:t-1]) - 1
过去30期对应 ARA.csv 交易日历上的前30个交易日；不包含当天，不填补缺失值。
输出 date,aia_option_proxy；日期和数字格式模仿 ARA.csv。
不输出缺失日期（不写空值行），数据起止日由实际有效观测决定。
Cboe 原始数据：https://cdn.cboe.com/resources/options/volume_and_call_put_ratios/indexpc.csv
"""

from __future__ import annotations

import csv
import re
import statistics
import sys
import urllib.request
from collections import deque
from datetime import date, datetime
from pathlib import Path

# 以脚本所在位置为准，与运行 Python 的当前目录无关。
SCRIPT_DIR = Path(__file__).resolve().parent
DATA_DIR = SCRIPT_DIR.parent
CBOE_FILE = SCRIPT_DIR / "indexpc.csv"
ARA_FILE = DATA_DIR / "ARA.csv"
OUTPUT_FILE = SCRIPT_DIR / "AIA_option_proxy.csv"
SOURCE_URL = "https://cdn.cboe.com/resources/options/volume_and_call_put_ratios/indexpc.csv"
START_DATE = date(2010, 2, 1)
END_DATE = date(2019, 12, 31)
WINDOW = 30


def parse_date(text: str) -> date:
    text = str(text).strip().strip('"').strip("'")
    for pattern in ("%d%b%Y", "%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y", "%Y%m%d"):
        try:
            return datetime.strptime(text, pattern).date()
        except ValueError:
            continue
    raise ValueError(f"无法识别日期：{text!r}")


def date_like_ara(value: date) -> str:
    # ARA.csv 中日期写法：01jul2004、31dec2019
    return value.strftime("%d%b%Y").lower()


def value_like_ara(number: float | None) -> str:
    # 本脚本只导出有效指标；传入缺失值即认为是程序错误。
    if number is None:
        raise ValueError("不应把缺失指标写入输出文件")
    text = f"{number:.9f}".rstrip("0").rstrip(".")
    if not text or text == "-0":
        return "0"
    # 与 ARA.csv 一致：0.25 -> .25；-0.25 -> -.25
    if text.startswith("0."):
        return text[1:]
    if text.startswith("-0."):
        return "-" + text[2:]
    return text


def read_ara_calendar(path: Path) -> list[date]:
    if not path.is_file():
        raise FileNotFoundError(f"找不到上一级数据目录中的 ARA：{path}")
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if "date" not in (reader.fieldnames or []):
            raise ValueError(f"{path.name} 缺少 date 列")
        all_dates = [parse_date(row["date"]) for row in reader if row.get("date", "").strip()]
    if len(set(all_dates)) != len(all_dates):
        raise ValueError("ARA.csv 有重复的交易日期，无法作为唯一交易日历")
    if not all_dates:
        raise ValueError("ARA.csv 没有可用日期")
    return sorted(all_dates)


def normalized_header(cell: str) -> str:
    return re.sub(r"[^a-z0-9]", "", cell.lower())


def parse_volume(cell: str) -> int | None:
    raw = str(cell).strip().replace(",", "").replace(" ", "")
    if not raw or raw.upper() in {"N/A", "NA", "NULL", ".", "-", "NAN"}:
        return None
    number = float(raw)
    if not number.is_integer() or number < 0:
        raise ValueError(f"异常成交量数值：{cell!r}")
    return int(number)


def read_cboe(path: Path) -> dict[date, int]:
    # Cboe CSV 可能在数据标题前有说明行，因此先搜索真正的字段标题。
    with path.open("r", encoding="utf-8-sig", errors="replace", newline="") as handle:
        rows = list(csv.reader(handle))
    header_idx = None
    positions = None
    for row_idx, row in enumerate(rows):
        cols = [normalized_header(x) for x in row]
        date_col = next((x for x in ("tradedate", "date") if x in cols), None)
        if date_col and all(x in cols for x in ("call", "put", "total")):
            header_idx = row_idx
            positions = [cols.index(x) for x in (date_col, "call", "put", "total")]
            break
    if positions is None:
        raise ValueError("indexpc.csv 无法识别 date/call/put/total 表头；请确认下载的是Cboe官方CSV")

    volume_by_date: dict[date, int] = {}
    invalid_rows = 0
    mismatch_rows = 0
    for row in rows[header_idx + 1:]:
        if len(row) <= max(positions):
            continue
        try:
            d = parse_date(row[positions[0]])
            call, put, total = [parse_volume(row[i]) for i in positions[1:]]
        except (TypeError, ValueError):
            invalid_rows += 1
            continue
        if total is None or total <= 0:
            invalid_rows += 1
            continue
        if call is not None and put is not None and call + put != total:
            mismatch_rows += 1
        if d in volume_by_date and volume_by_date[d] != total:
            raise ValueError(f"Cboe文件日期 {d} 有不同的成交量记录，不能自动合并")
        volume_by_date[d] = total
    if not volume_by_date:
        raise ValueError("Cboe文件中未读到有效的日期与指数期权成交量")
    print(f"Cboe有效记录：{len(volume_by_date)} 日（{min(volume_by_date)} 至 {max(volume_by_date)}）")
    if invalid_rows:
        print(f"提示：跳过 {invalid_rows} 行无效/缺失数据或说明文字")
    if mismatch_rows:
        print(f"提示：{mismatch_rows} 行 Call+Put 不等于 Total；使用官方 Total 列")
    return volume_by_date


def fetch_if_needed() -> None:
    if CBOE_FILE.exists():
        return
    print("本地没有 indexpc.csv，尝试从 Cboe 官网下载……")
    try:
        request = urllib.request.Request(SOURCE_URL, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(request, timeout=40) as response:
            body = response.read()
        if len(body) < 1000 or b"<html" in body[:300].lower():
            raise RuntimeError("服务器未返回有效的CSV文件")
        CBOE_FILE.write_bytes(body)
        print(f"原始数据已保存：{CBOE_FILE}")
    except Exception as exc:
        raise RuntimeError(
            "自动下载失败。请用浏览器打开以下网址，保存为 indexpc.csv 并放入脚本所在文件夹：\n"
            f"{SOURCE_URL}\n原因：{exc}"
        ) from exc


def build_proxy(trading_days: list[date], volume_by_date: dict[date, int]) -> list[tuple[date, float | None]]:
    # 使用 ARA 日期控制交易日顺序，避免自然日窗口/休市日期混入。
    past_30 = deque(maxlen=WINDOW)
    results: list[tuple[date, float | None]] = []
    for d in trading_days:
        volume = volume_by_date.get(d)
        proxy = None
        # 严格要求前30个交易日的每一天都有有效成交量。
        if volume is not None and volume > 0 and len(past_30) == WINDOW:
            if all(v is not None and v > 0 for v in past_30):
                denominator = statistics.median(past_30)
                if denominator > 0:
                    proxy = volume / denominator - 1
        past_30.append(volume)
        if START_DATE <= d <= END_DATE:
            results.append((d, proxy))
    if not results:
        raise ValueError("ARA.csv 中没有2010年2月至2019年12月的交易日")
    if not any(value is not None for _, value in results):
        raise ValueError("没有构造出任何有效指标，请检查Cboe日期、表头及数据期间")
    return results


def main() -> None:
    trading_days = read_ara_calendar(ARA_FILE)
    fetch_if_needed()
    volume_by_date = read_cboe(CBOE_FILE)
    records = build_proxy(trading_days, volume_by_date)

    # 唯一输出：保存到脚本所在 AIA_option_proxy 文件夹。
    # 仅导出有效指标日；没有原始成交量或缺少完整30日窗口的日期直接跳过。
    valid = [(d, v) for d, v in records if v is not None]
    missing = len(records) - len(valid)
    with OUTPUT_FILE.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["date", "aia_option_proxy"])
        for d, value in valid:
            writer.writerow([date_like_ara(d), value_like_ara(value)])

    print(f"输出：{OUTPUT_FILE}")
    print(f"目标日期范围：{START_DATE} 至 {END_DATE}（以ARA交易日历为准）")
    print(f"成功输出：{len(valid)} 行；因当日缺失或滚动窗口不完整跳过：{missing} 日")
    print(f"输出有效日期范围：{valid[0][0]} 至 {valid[-1][0]}")
    if max(volume_by_date) < END_DATE:
        print(f"注意：Cboe原始数据最晚为 {max(volume_by_date)}；之后的日期没有有效指标，CSV中不出现。")
    print("注意：aia_option_proxy是指数期权异常成交量代理，不是原论文的Bloomberg AIA。")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, FileNotFoundError, RuntimeError) as error:
        print(f"错误：{error}", file=sys.stderr)
        sys.exit(1)
