#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""从公开 sp500d.csv 构造论文复现使用的 S&P 500 范围 vwret 代理序列。

文件结构：
    data/
    ├── ARA.csv                       # 已有，用作统一交易日历，不修改
    └── vwret/
        ├── build_vwret.py             # 本程序
        ├── sp500d.csv                 # 官方来源：CRSP dsp500；公开课程样本
        └── vwret.csv                  # 唯一生成的输出，date,vwret

原始数据：https://raw.githubusercontent.com/lukestein-classes/fdap/main/data/sp500d.csv
来源说明：https://lukestein-classes.github.io/fdap/data/

输入字段：caldt（日期），vwretx（市值加权收益率，不含股息；小数单位）。
输出字段：date（如26jan2010），vwret（百分数数值，如1.4218表示1.4218%）。
正式分析期：2010-02-01 至 2019-10-04；原始收益率日期额外保留前4、后6个交易日。

本文件来自 CRSP S&P 500 指数数据集 dsp500，并非原论文全市场 CRSP VWRETX。
因此输出是替代因变量，请勿声称严格重现原文 Table 2/4 的数值。

运行：在 vwret 文件夹中执行 python3 build_vwret.py
如本地缺少 sp500d.csv，程序会尝试自动下载；若失败请手动从上面的链接下载。
仅使用 Python 3 标准库。
"""
from __future__ import annotations

import csv
import io
import sys
import urllib.request
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
ARA_FILE = SCRIPT_DIR.parent / "ARA.csv"
SOURCE_FILE = SCRIPT_DIR / "sp500d.csv"
OUTPUT_FILE = SCRIPT_DIR / "vwret.csv"
SOURCE_URL = "https://raw.githubusercontent.com/lukestein-classes/fdap/main/data/sp500d.csv"

ANALYSIS_START = date(2010, 2, 1)
ANALYSIS_END = date(2019, 10, 4)
PREVIOUS_TRADING_DAYS = 4
FOLLOWING_TRADING_DAYS = 6
MONTH_NAMES = ("jan", "feb", "mar", "apr", "may", "jun",
               "jul", "aug", "sep", "oct", "nov", "dec")


def parse_date(s: str) -> date:
    s = str(s).strip().strip('"').strip("'")
    # ARA.csv 使用英文月份，例如 01feb2010；不依赖操作系统区域设置。
    if len(s) == 9 and s[2:5].lower() in MONTH_NAMES:
        m = MONTH_NAMES.index(s[2:5].lower()) + 1
        return date(int(s[5:9]), m, int(s[:2]))
    for fmt in ("%Y-%m-%d", "%Y-%m-%d %H:%M:%S", "%m/%d/%Y", "%m/%d/%y", "%Y%m%d"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    raise ValueError(f"无法识别日期：{s!r}")


def format_ara_date(d: date) -> str:
    return f"{d.day:02d}{MONTH_NAMES[d.month - 1]}{d.year:04d}"


def format_percent(value: Decimal) -> str:
    # 输入 0.014218 → 输出 1.4218（百分点）；风格与 ARA.csv 相同。
    n = value * Decimal(100)
    s = format(n, ".9f").rstrip("0").rstrip(".")
    if s in ("", "-0"):
        return "0"
    if s.startswith("0."):
        return s[1:]
    if s.startswith("-0."):
        return "-" + s[2:]
    return s


def load_ara_calendar(path: Path) -> list[date]:
    if not path.is_file():
        raise FileNotFoundError(f"找不到 {path}；请将 ARA.csv 放在 vwret 文件夹的上一级。")
    with path.open(encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None or "date" not in reader.fieldnames:
            raise ValueError("ARA.csv 缺少 date 列")
        days = [parse_date(row["date"]) for row in reader if row.get("date", "").strip()]
    if len(days) != len(set(days)):
        raise ValueError("ARA.csv 存在重复日期")
    days.sort()
    if not days or ANALYSIS_START not in days or ANALYSIS_END not in days:
        raise ValueError("ARA.csv 必须包含分析起止日期 2010-02-01 与 2019-10-04")
    return days


def ensure_source_file() -> None:
    if SOURCE_FILE.is_file():
        print(f"使用本地原始文件：{SOURCE_FILE}")
        return
    print("本地没有 sp500d.csv，尝试下载大学课程公开 CRSP S&P 500 数据……")
    try:
        request = urllib.request.Request(SOURCE_URL, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(request, timeout=60) as resp:
            body = resp.read()
        if len(body) < 10000 or not body.lstrip(b"\xef\xbb\xbf\r\n ").lower().startswith(b"caldt,"):
            raise ValueError("下载结果不是预期的 caldt,...,vwretx CSV")
        SOURCE_FILE.write_bytes(body)
        print(f"原始文件下载完成：{SOURCE_FILE}（{len(body):,}字节）")
    except Exception as exc:
        raise RuntimeError(
            "无法自动下载 sp500d.csv。请在浏览器中手动下载并保存到当前 vwret 文件夹：\n"
            f"{SOURCE_URL}\n失败原因：{exc}"
        ) from exc


def load_vwretx(path: Path) -> dict[date, Decimal]:
    # 本方案固定读取 sp500d.csv 的 caldt 与 vwretx；其他字段不参与计算。
    result: dict[date, Decimal] = {}
    with path.open(encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames:
            raise ValueError("sp500d.csv 没有表头")
        cols = {col.strip().lower(): col for col in reader.fieldnames}
        if "caldt" not in cols or "vwretx" not in cols:
            raise ValueError(f"sp500d.csv 应包含 caldt、vwretx；实际字段为 {reader.fieldnames}")
        for row in reader:
            raw_d = (row.get(cols["caldt"]) or "").strip()
            raw_v = (row.get(cols["vwretx"]) or "").strip()
            if not raw_d or not raw_v:
                continue
            try:
                day = parse_date(raw_d)
                value = Decimal(raw_v)
            except (ValueError, InvalidOperation):
                continue
            if not value.is_finite():
                continue
            if day in result and result[day] != value:
                raise ValueError(f"sp500d.csv 在 {day} 存在冲突的 vwretx 记录")
            result[day] = value
    if not result:
        raise ValueError("sp500d.csv 没有任何有效的 caldt/vwretx 记录")
    return result


def main() -> None:
    calendar = load_ara_calendar(ARA_FILE)
    first = calendar.index(ANALYSIS_START)
    last = calendar.index(ANALYSIS_END)
    if first < PREVIOUS_TRADING_DAYS or last + FOLLOWING_TRADING_DAYS >= len(calendar):
        raise ValueError("ARA.csv 不足以覆盖分析期之前4期和之后6期")
    output_days = calendar[first - PREVIOUS_TRADING_DAYS:
                           last + FOLLOWING_TRADING_DAYS + 1]

    ensure_source_file()
    market = load_vwretx(SOURCE_FILE)
    missing = [d for d in output_days if d not in market]
    if missing:
        sample = ", ".join(x.isoformat() for x in missing[:8])
        raise ValueError(
            f"sp500d.csv 在必须保留的扩展交易日中缺失 {len(missing)} 天：{sample}。"
            "为避免未来收益率错位，程序停止且不输出不完整指标。"
        )

    # 唯一输出：只包含 date,vwret；不生成任何中间表格或未来/滞后回报。
    with OUTPUT_FILE.open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["date", "vwret"])
        writer.writerows((format_ara_date(d), format_percent(market[d])) for d in output_days)

    print(f"输出完成：{OUTPUT_FILE}")
    print(f"数据源：sp500d.csv（CRSP dsp500 / S&P 500 范围）")
    print(f"正式分析期：{ANALYSIS_START} 至 {ANALYSIS_END}；{last - first + 1:,} 个交易日")
    print(f"数据缓冲：向前 {PREVIOUS_TRADING_DAYS} 天、向后 {FOLLOWING_TRADING_DAYS} 天")
    print(f"实际输出：{output_days[0]} 至 {output_days[-1]}；{len(output_days):,} 行")
    print("CSV：date,vwret；收益率已乘100，后续请勿重复乘100。")
    print("此指标是 S&P 500 范围的 VWRETX 替代值，不等于论文全市场原始 VWRETX。")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, FileNotFoundError, RuntimeError) as exc:
        print(f"错误：{exc}", file=sys.stderr)
        sys.exit(1)
