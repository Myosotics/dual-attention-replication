#!/usr/bin/env python3
"""从本文件夹内保存的公开源文件生成单指标 CSV；不会联网或填造缺失值。"""
from __future__ import annotations
import csv
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = HERE / 'Baker_Wurgler_SENTIMENT.xlsx'
OUTPUT = HERE / 'lBWx_monthly_proxy.csv'
KIND = 'bw_lag'
COLUMN = 'lBWx_monthly_proxy'

def rows():
    if KIND in ('vix', 'tms', 'dfy', 'epu_ma7', 'epu_monthly'):
        with SOURCE.open(encoding='utf-8-sig', newline='') as f:
            data = list(csv.DictReader(f))
        for r in data:
            if KIND == 'vix':
                d = datetime.strptime(r['DATE'], '%m/%d/%Y').date()
                value = r['CLOSE']
            elif KIND in ('tms', 'dfy'):
                d = datetime.strptime(r['yyyymm'], '%Y%m').date()
                raw = r[KIND]
                value = '' if raw == '' else format(float(raw) * 100, '.12g')
            elif KIND == 'epu_ma7':
                d = datetime(int(r['year']), int(r['month']), int(r['day'])).date()
                value = r['daily_policy_moving_average']
            else:
                d = datetime(int(r['Year']), int(r['Month']), 1).date()
                value = r['News_Based_Policy_Uncert_Index']
            if value not in ('', None):
                yield d.isoformat(), value
    else:
        import pandas as pd
        if KIND == 'ads':
            frame = pd.read_excel(SOURCE)
            frame['date'] = pd.to_datetime(frame['Date'].astype(str).str.replace(':', '-', regex=False))
            frame = frame.sort_values('date')
            frame['value'] = pd.to_numeric(frame['ADS_Index'], errors='coerce').diff()
        else:
            frame = pd.read_excel(SOURCE, sheet_name='DATA')
            frame['date'] = pd.to_datetime(frame['yearmo'].astype(int).astype(str), format='%Y%m')
            frame = frame.sort_values('date')
            source_col = 'SENT_ORTH' if KIND == 'bw_orth' else 'SENT'
            frame['value'] = pd.to_numeric(frame[source_col], errors='coerce')
            if KIND == 'bw_lag':
                frame['value'] = frame['value'].shift(1)
        for _, r in frame.iterrows():
            if pd.notna(r['value']):
                yield r['date'].date().isoformat(), format(float(r['value']), '.12g')

def main():
    data = list(rows())
    if len(data) != len({d for d, _ in data}):
        raise ValueError('源数据存在重复日期')
    with OUTPUT.open('w', encoding='utf-8', newline='') as f:
        w = csv.writer(f)
        w.writerow(['date', COLUMN])
        w.writerows(data)
    print(f'生成 {OUTPUT.name}：{len(data)} 行；{data[0][0]} 至 {data[-1][0]}')

if __name__ == '__main__':
    main()
