# lBWx_一月滞后近似

- 状态：**真实公开数据的近似转换**。
- 来源：将 Baker-Wurgler 月度 SENT 整体滞后一个月；member2混合面板的近似口径。
- 来源地址：https://www.stern.nyu.edu/~jwurgler/data/SENTIMENT.xlsx
- 原始文件：`Baker_Wurgler_SENTIMENT.xlsx`，已包含在本文件夹。
- 单指标输出：`lBWx_monthly_proxy.csv`，列为 `date,lBWx_monthly_proxy`，日期 ISO 格式。已预生成；需要时可重建：

```bash
python3 build.py
```

需要 pandas 和 openpyxl；安装方式见根目录 `requirements.txt`。 脚本不会联网，也不会用模拟值填缺口。

**使用边界：**只输出月度值，不自动做日度填充；作者最终控制变量口径需核对。
