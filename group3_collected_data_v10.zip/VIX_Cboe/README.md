# VIX_Cboe

- 状态：**真实公开数据**。
- 来源：Cboe VIX History；本文件取日度 CLOSE，保留源文件全部日期。
- 来源地址：https://cdn.cboe.com/api/global/us_indices/daily_prices/VIX_History.csv
- 原始文件：`VIX_History.csv`，已包含在本文件夹。
- 单指标输出：`VIX.csv`，列为 `date,VIX`，日期 ISO 格式。已预生成；需要时可重建：

```bash
python3 build.py
```

本脚本仅使用 Python 3 标准库。 脚本不会联网，也不会用模拟值填缺口。

**使用边界：**与论文 VIX 指标同类；最终回归须在完整交易日历上对齐并计算滞后。
