# BW_SENT_ORTH_月度

- 状态：**真实公开月度数据（备查）**。
- 来源：Baker-Wurgler SENTIMENT 工作簿 DATA 页 SENT_ORTH 列。
- 来源地址：https://www.stern.nyu.edu/~jwurgler/data/SENTIMENT.xlsx
- 原始文件：`Baker_Wurgler_SENTIMENT.xlsx`，已包含在本文件夹。
- 单指标输出：`BW_SENT_ORTH_monthly.csv`，列为 `date,BW_SENT_ORTH`，日期 ISO 格式。已预生成；需要时可重建：

```bash
python3 build.py
```

需要 pandas 和 openpyxl；安装方式见根目录 `requirements.txt`。 脚本不会联网，也不会用模拟值填缺口。

**使用边界：**这是备查指标，原项目混合回归使用的是 SENT 一月滞后近似列，而非此列。
