#!/usr/bin/env python3
"""从 member1 保存的 Yahoo SPY JSON 构建异常成交量代理；仅用 Python 标准库。"""
import csv
import json
import math
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
WINDOW = 252


def main():
    payload = json.loads((HERE / 'SPY_Yahoo_2003_2019.json').read_text(encoding='utf-8-sig'))
    chart = payload['chart']
    if chart.get('error') or len(chart.get('result') or []) != 1:
        raise ValueError('行情接口返回错误或结果不唯一')
    result = chart['result'][0]
    if result['meta']['symbol'] != 'SPY':
        raise ValueError('标的不是 SPY')
    timestamps = result['timestamp']
    volumes = result['indicators']['quote'][0]['volume']
    if len(timestamps) != len(volumes):
        raise ValueError('日期和成交量长度不一致')
    dates = [datetime.fromtimestamp(t, timezone.utc).astimezone(
        ZoneInfo('America/New_York')).date().isoformat() for t in timestamps]
    if dates != sorted(set(dates)):
        raise ValueError('日期重复或未排序')
    if any(v is None or not isinstance(v, (int, float)) or not math.isfinite(v) or v <= 0 for v in volumes):
        raise ValueError('成交量存在无效值；不得补零或跨缺失计算')
    logs = [math.log(v) for v in volumes]
    # 均值不含当期，不使用未来观测；252 为本代理自行选取的一年近似。
    values = {dates[i]: logs[i] - math.fsum(logs[i-WINDOW:i]) / WINDOW
              for i in range(WINDOW, len(dates))}
    with (HERE.parent / 'ARA.csv').open(encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        if 'date' not in reader.fieldnames:
            raise ValueError('ARA.csv 缺少 date 列')
        targets = [datetime.strptime(row['date'], '%d%b%Y').date().isoformat() for row in reader]
    if targets != sorted(set(targets)):
        raise ValueError('ARA 目标日历重复或未排序')
    missing = [d for d in targets if d not in values]
    if missing:
        raise ValueError(f'目标日期缺少成交量或252日历史：{missing[:10]}')
    with (HERE / 'SPY_daily_volume.csv').open('w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['date', 'volume'])
        writer.writerows(zip(dates, volumes))
    with (HERE / 'AbnTurn_volume_proxy.csv').open('w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['date', 'AbnTurn_volume_proxy'])
        writer.writerows((d, format(values[d], '.12f')) for d in targets)
    print(f'SPY成交量 {len(dates)} 行；代理 {len(targets)} 行，{targets[0]} 至 {targets[-1]}，无缺失。')


if __name__ == '__main__':
    main()
