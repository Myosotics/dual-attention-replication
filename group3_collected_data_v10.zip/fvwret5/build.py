#!/usr/bin/env python3
"""从相邻指标目录的实际日收益率计算 t+2 至 t+6 复合回报。"""
import csv
from pathlib import Path
from datetime import date
from decimal import Decimal
HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'vwret_标普500替代' / 'vwret.csv'
CALENDAR = HERE.parent / 'ARA.csv'
START = date(2010, 2, 1)
END = date(2019, 10, 4)
MONTHS = {m:i+1 for i,m in enumerate(('jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'))}

def day(text):
    s=text.strip().lower()
    return date(int(s[5:]),MONTHS[s[2:5]],int(s[:2]))

def main():
    with SOURCE.open(encoding='utf-8-sig',newline='') as f:
        data=[(day(r['date']),Decimal(r['vwret'])) for r in csv.DictReader(f)]
    data.sort()
    if len({d for d,_ in data}) != len(data):raise ValueError('日收益率存在重复日期')
    with CALENDAR.open(encoding='utf-8-sig',newline='') as f:
        calendar=sorted(day(r['date']) for r in csv.DictReader(f))
    if len(set(calendar))!=len(calendar):raise ValueError('交易日历存在重复日期')
    supplied=[d for d,_ in data]
    expected=[d for d in calendar if supplied[0]<=d<=supplied[-1]]
    if supplied!=expected:raise ValueError('日收益率与 ARA 交易日历不一致；不能跳过缺失交易日计算')
    result=[]
    for i,(d,_) in enumerate(data):
        if not START<=d<=END:continue
        if i+6>=len(data):raise ValueError(f'{d} 缺少未来6个交易日缓冲')
        product=Decimal(1)
        for j in range(2,7):
            ret=data[i+j][1]
            if not ret.is_finite() or ret<=-100:raise ValueError('无效日收益率')
            product*=Decimal(1)+ret/Decimal(100)
        result.append((d.isoformat(),format((product-1)*100,'.12f')))
    target=[d.isoformat() for d in calendar if START<=d<=END]
    if [d for d,_ in result]!=target:raise ValueError('分析期日期覆盖不完整')
    with (HERE/'fvwret5.csv').open('w',encoding='utf-8',newline='') as f:
        w=csv.writer(f);w.writerow(['date','fvwret5']);w.writerows(result)
    print(f'生成 {len(result)} 行：{result[0][0]} 至 {result[-1][0]}；单位为百分数')

if __name__=='__main__':main()
