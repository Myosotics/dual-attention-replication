#!/usr/bin/env python3
"""Generate a deterministic synthetic panel for Group 3's method demonstration."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Tuple

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_ARA = ROOT / "supplement" / "datasubmission" / "ARA.csv"
DEFAULT_OUTPUT = ROOT / "data" / "simulated_panel.csv"
DEFAULT_METADATA = ROOT / "output" / "simulation_metadata.json"
SEED = 20241107


def ar1_series(
    rng: np.random.Generator,
    n: int,
    mean: float,
    std: float,
    phi: float,
) -> np.ndarray:
    burn = 1000
    innovation_std = std * np.sqrt(max(1.0 - phi**2, 0.0))
    values = np.empty(n + burn, dtype=float)
    values[0] = mean
    for index in range(1, n + burn):
        values[index] = (
            mean
            + phi * (values[index - 1] - mean)
            + rng.normal(scale=innovation_std)
        )
    result = values[burn:]
    return (result - result.mean()) / result.std(ddof=1) * std + mean


def calibrated_aia(
    rng: np.random.Generator, n: int
) -> np.ndarray:
    latent = ar1_series(rng, n, mean=0.0, std=1.0, phi=0.57)
    values = np.clip(0.254 + 0.10 * latent, 0.0, 0.7112147)
    for _ in range(10):
        values = (
            (values - values.mean())
            / values.std(ddof=1)
            * 0.10
            + 0.254
        )
        values = np.clip(values, 0.0, 0.7112147)
    return values


def _two_exact_groups(
    rng: np.random.Generator,
    n_high: int,
    n_low: int,
) -> Tuple[np.ndarray, np.ndarray]:
    high = np.empty(n_high)
    low = np.empty(n_low)
    for index in range(n_high):
        value = 0.0
        while value <= 15.57:
            value = rng.normal(loc=21.5, scale=7.5)
        high[index] = value
    for index in range(n_low):
        value = 99.0
        while value > 15.57:
            value = rng.normal(loc=14.8, scale=4.8)
        low[index] = value
    return high, low


def generate_panel(
    ara_path: Path = DEFAULT_ARA,
    seed: int = SEED,
) -> Tuple[pd.DataFrame, dict]:
    ara_dates = pd.read_csv(ara_path)
    ara_dates["date"] = pd.to_datetime(
        ara_dates["date"], format="%d%b%Y", errors="raise"
    )
    final_dates = pd.DatetimeIndex(ara_dates["date"].sort_values())

    # Preserve four pre-sample rows so every lagged control is available for the
    # first paper observation, as in the author's prepared final dataset.
    prior_dates = pd.bdate_range(
        final_dates[0] - pd.offsets.BDay(4),
        final_dates[0] - pd.offsets.BDay(1),
    )
    dates = pd.DatetimeIndex(prior_dates).append(final_dates).drop_duplicates()
    n = len(dates)
    final_mask = dates.isin(final_dates)
    rng = np.random.default_rng(seed)

    panel = pd.DataFrame({"date": dates})
    panel["ara"] = ar1_series(rng, n, mean=0.064763, std=0.0540132, phi=0.77)

    panel["aia"] = np.nan
    aia_mask = panel["date"] >= pd.Timestamp("2010-02-16")
    aia_candidates = panel.index[aia_mask].to_numpy()
    panel.loc[aia_candidates, "aia"] = calibrated_aia(rng, len(aia_candidates))
    # The paper reports 2,431 complete AIA observations despite the AIA series
    # beginning in February 2010. Preserve the boundaries and mark 56 interior
    # synthetic days missing so the simulation has the same observed sample size.
    missing_aia = rng.choice(
        aia_candidates[1:-1], size=56, replace=False
    )
    panel.loc[missing_aia, "aia"] = np.nan

    panel["tms"] = np.clip(
        ar1_series(rng, n, mean=2.991371, std=1.744539, phi=0.98),
        -0.1475,
        6.5646,
    )
    panel["dfy"] = np.clip(
        ar1_series(rng, n, mean=1.062949, std=0.4660397, phi=0.99),
        0.53,
        3.50,
    )
    panel["abn_news"] = ar1_series(
        rng, n, mean=0.0003239, std=0.1063912, phi=0.20
    )
    panel["lBWx"] = ar1_series(
        rng, n, mean=-0.0988447, std=0.3112685, phi=0.90
    )
    panel["dADS"] = ar1_series(
        rng, n, mean=0.0, std=0.0278038, phi=0.35
    )
    panel["dEPU"] = ar1_series(
        rng, n, mean=0.0, std=53.80941, phi=0.20
    )
    panel["abnto"] = ar1_series(
        rng, n, mean=-0.1146313, std=0.2202317, phi=0.70
    )

    # Exactly reproduce the paper's observed number of high/low observations
    # in the real-data tables. This makes the synthetic sample design comparable
    # without claiming that the synthetic estimates are real-data replications.
    n_high_vix, n_low_vix = 1951, 1952
    high_vix, low_vix = _two_exact_groups(rng, n_high_vix, n_low_vix)
    vix_final = np.concatenate([high_vix, low_vix])
    rng.shuffle(vix_final)
    panel.loc[final_mask, "VIX"] = vix_final
    prior_vix = ar1_series(rng, int((~final_mask).sum()), 18.0, 8.0, 0.95)
    panel.loc[~final_mask, "VIX"] = prior_vix

    panel["percentspread"] = np.nan
    spread_high = rng.uniform(0.0005240, 0.0010, size=n_high_vix)
    spread_low = rng.uniform(0.00020, 0.0005239, size=n_low_vix)
    spread_final = np.concatenate([spread_high, spread_low])
    rng.shuffle(spread_final)
    panel.loc[final_mask, "percentspread"] = spread_final
    panel.loc[~final_mask, "percentspread"] = ar1_series(
        rng, int((~final_mask).sum()), 0.0005239, 0.00018, 0.8
    )

    panel["mnews26"] = 0
    panel["news26"] = 0
    aia_indices = panel.index[panel["aia"].notna()].to_numpy()
    high_vix_aia_indices = panel.index[
        panel["aia"].notna() & (panel["VIX"] > 15.57)
    ].to_numpy()
    n_macro_from_high = min(1219, len(high_vix_aia_indices))
    selected_macro = list(
        rng.choice(
            high_vix_aia_indices,
            size=n_macro_from_high,
            replace=False,
        )
    )
    if n_macro_from_high < 1219:
        remaining_macro_candidates = np.setdiff1d(
            aia_indices,
            np.asarray(selected_macro),
            assume_unique=False,
        )
        selected_macro.extend(
            rng.choice(
                remaining_macro_candidates,
                size=1219 - n_macro_from_high,
                replace=False,
            ).tolist()
        )
    selected_macro = np.asarray(selected_macro)
    remaining = np.setdiff1d(aia_indices, selected_macro, assume_unique=False)
    selected_extra_news = rng.choice(
        remaining, size=1395 - 1219, replace=False
    )
    panel.loc[selected_macro, "mnews26"] = 1
    panel.loc[selected_extra_news, "news26"] = 1
    panel["news26"] = ((panel["mnews26"] == 1) | (panel["news26"] == 1)).astype(int)

    panel["dfee"] = np.nan
    fee_dates = panel["date"].between("2006-07-01", "2011-12-31")
    fee_indices = panel.index[fee_dates].to_numpy()
    selected_fee = rng.choice(fee_indices, size=1255, replace=False)
    panel.loc[selected_fee[:627], "dfee"] = 1
    panel.loc[selected_fee[627:], "dfee"] = 0

    high_vix = (panel["VIX"] > 15.57).astype(float)
    high_spread = (panel["percentspread"] > 0.0005239).astype(float)
    high_fee = panel["dfee"].fillna(0.0)
    aia_zero = panel["aia"].fillna(0.0)

    ara_effect = (
        -3.0
        - 2.0 * high_vix
        - 2.0 * high_spread
        - 12.0 * high_fee
    )
    news_effect = 2.0 * aia_zero * panel["news26"]
    aia_state_effect = (
        (0.35 * high_vix + 0.10 * high_spread)
        * aia_zero
        * panel["news26"]
    )
    structural = (
        0.03
        + ara_effect * panel["ara"]
        + news_effect
        + aia_state_effect
        + 0.04 * panel["VIX"]
        - 0.04 * panel["tms"]
        - 0.10 * panel["dfy"]
        + 0.10 * panel["abn_news"]
        - 0.20 * panel["lBWx"]
        - 1.00 * panel["dADS"]
        + 0.001 * panel["dEPU"]
        - 0.10 * panel["abnto"]
    )
    panel["fvwret5"] = structural + rng.normal(scale=0.90, size=n)
    panel["vwret"] = rng.normal(loc=0.0317765, scale=1.146197, size=n)

    panel["retail_bhjos_vol"] = np.nan
    panel["retail_bhjos_vol2"] = np.nan
    panel["equityflow"] = np.nan
    panel["ins_oib"] = np.nan
    retail_mask = panel["date"] >= pd.Timestamp("2010-01-04")
    negative = panel["vwret"] < 0
    bottom_roi = panel["vwret"] < -1.548332
    bottom_fund = panel["vwret"] < -1.856066
    panel.loc[retail_mask, "retail_bhjos_vol"] = (
        3.555 * panel.loc[retail_mask, "ara"]
        + 3.4 * panel.loc[retail_mask, "ara"] * negative.loc[retail_mask]
        + 6.9 * panel.loc[retail_mask, "ara"] * bottom_roi.loc[retail_mask]
        + rng.normal(scale=0.12, size=int(retail_mask.sum()))
    )
    panel.loc[retail_mask, "retail_bhjos_vol2"] = (
        0.237 * panel.loc[retail_mask, "ara"]
        + 0.17 * panel.loc[retail_mask, "ara"] * negative.loc[retail_mask]
        + 0.19 * panel.loc[retail_mask, "ara"] * bottom_roi.loc[retail_mask]
        + rng.normal(scale=0.012, size=int(retail_mask.sum()))
    )
    fund_mask = panel["date"].between("2004-07-01", "2016-07-31")
    panel.loc[fund_mask, "equityflow"] = (
        0.187 * panel.loc[fund_mask, "ara"]
        + 0.02 * panel.loc[fund_mask, "ara"] * bottom_fund.loc[fund_mask]
        + rng.normal(scale=0.008, size=int(fund_mask.sum()))
    )
    ins_mask = retail_mask
    panel.loc[ins_mask, "ins_oib"] = (
        0.376 * panel.loc[ins_mask, "aia"]
        + 0.879 * panel.loc[ins_mask, "aia"] * panel.loc[ins_mask, "mnews26"]
        + rng.normal(scale=0.025, size=int(ins_mask.sum()))
    )

    for variable in ("VIX",):
        panel[f"l{variable}"] = panel[variable].shift(1)
        panel[f"l2{variable}"] = panel[variable].shift(2)
        panel[f"l3{variable}"] = panel[variable].shift(3)
        panel[f"l4{variable}"] = panel[variable].shift(4)
    for prefix, variable in (
        ("", "vwret"),
        ("l", "vwret"),
        ("l2", "vwret"),
        ("l3", "vwret"),
        ("l4", "vwret"),
        ("", "abnto"),
        ("l", "abnto"),
        ("l2", "abnto"),
        ("l3", "abnto"),
        ("l4", "abnto"),
    ):
        if variable == "vwret" and prefix == "":
            continue
        if variable == "abnto" and prefix == "":
            continue
        lag = 0 if prefix == "" else int(prefix.replace("l", "") or 1)
        panel[f"{prefix}{variable}"] = panel[variable].shift(lag)

    final = panel.loc[final_mask].copy().reset_index(drop=True)
    required_complete = [
        "fvwret5",
        "ara",
        *[
            "tms",
            "dfy",
            "abn_news",
            "lBWx",
            "dADS",
            "dEPU",
            "VIX",
            "lVIX",
            "l2VIX",
            "l3VIX",
            "l4VIX",
            "vwret",
            "lvwret",
            "l2vwret",
            "l3vwret",
            "l4vwret",
            "abnto",
            "labnto",
            "l2abnto",
            "l3abnto",
            "l4abnto",
        ],
    ]
    if final[required_complete].isna().any().any():
        bad = final[required_complete].columns[
            final[required_complete].isna().any()
        ].tolist()
        raise RuntimeError("Simulation left required columns missing: " + str(bad))
    if len(final) != 3903:
        raise RuntimeError(f"Expected 3903 observations, obtained {len(final)}")
    if final["date"].duplicated().any():
        raise RuntimeError("Simulation contains duplicate dates")

    metadata = {
        "seed": seed,
        "classification": "SIMULATED - NOT AN EXACT REPLICATION",
        "n_rows": int(len(final)),
        "sample_start": str(final["date"].min().date()),
        "sample_end": str(final["date"].max().date()),
        "n_aia": int(final["aia"].notna().sum()),
        "ara_stats": {
            "mean": float(final["ara"].mean()),
            "std": float(final["ara"].std()),
            "lag1": float(final["ara"].autocorr(1)),
        },
        "aia_stats": {
            "mean": float(final["aia"].mean()),
            "std": float(final["aia"].std()),
            "min": float(final["aia"].min()),
            "max": float(final["aia"].max()),
        },
        "counts": {
            "high_vix": int((final["VIX"] > 15.57).sum()),
            "low_vix": int((final["VIX"] <= 15.57).sum()),
            "high_spread": int((final["percentspread"] > 0.0005239).sum()),
            "low_spread": int((final["percentspread"] <= 0.0005239).sum()),
            "high_fee": int((final["dfee"] == 1).sum()),
            "low_fee": int((final["dfee"] == 0).sum()),
            "macro_news": int((final["mnews26"] == 1).sum()),
            "all_news": int((final["news26"] == 1).sum()),
        },
        "dgp": (
            "ARA_t = 0.064763 + 0.77(ARA_{t-1}-0.064763) + e_t; "
            "fvwret5_t = 0.03 + [-3 - 2*HighVIX - 2*HighSpread "
            "- 12*HighFee]*ARA_t + 2*AIA_t*News_t "
            "+ (0.35*HighVIX + 0.10*HighSpread)*AIA_t*News_t "
            "+ 0.04*VIX_t - 0.04*TMS_t - 0.10*DFY_t + 0.10*AbnNews_t "
            "- 0.20*lBWx_t - 1.00*dADS_t + 0.001*dEPU_t "
            "- 0.10*AbnTurn_t + epsilon_t, epsilon ~ N(0,0.90^2)"
        ),
        "simplifications": [
            "The synthetic calendar uses the dates in the supplied ARA.csv.",
            "News-window indicators are random draws with paper-comparable counts.",
            "Retail and institutional trading variables follow reduced-form synthetic DGPs.",
            "The DGP intentionally omits higher-order dependence and realistic fat tails.",
        ],
    }
    return final, metadata


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ara", type=Path, default=DEFAULT_ARA)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--metadata", type=Path, default=DEFAULT_METADATA)
    args = parser.parse_args()

    panel, metadata = generate_panel(args.ara, seed=SEED)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.metadata.parent.mkdir(parents=True, exist_ok=True)
    panel.to_csv(args.output, index=False)
    args.metadata.write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"Simulation written to {args.output}")
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

