#!/usr/bin/env python3
"""Parse official archived event dates and construct a trading-day t+2:t+6 window."""
import csv,re,html,json
from pathlib import Path
from datetime import datetime,date
from collections import Counter
from urllib.parse import urljoin
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
RAW=HERE/'raw'
END=date(2020,1,31)

def save(name,fields,records):
    with (HERE/name).open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(records)

def parse_events():
    result=[]
    for year in range(2004,2021):
        source=f'https://www.federalreserve.gov/monetarypolicy/fomchistorical{year}.htm'
        text=(RAW/f'fomc_{year}.html').read_text(encoding='utf-8-sig')
        found=[]
        for part in re.split(r'<h5[^>]*>',text,flags=re.I)[1:]:
            heading,body=part.split('</h5>',1)
            title=html.unescape(re.sub('<[^>]+>','',heading)).strip()
            if 'meeting' not in title.lower() or any(x in title.lower() for x in ['unscheduled','cancelled','conference']):continue
            links=re.findall(r'<a[^>]+href="([^"]+)"[^>]*>\s*Statement\s*</a>',body,re.I)
            if len(links)!=1:raise ValueError(f'会议声明匹配异常：{title}: {links}')
            link=urljoin(source,html.unescape(links[0]))
            stamp=re.search(r'(20\d{6})(?:[a-z]?\.htm|/)' ,link)
            if not stamp:raise ValueError('声明链接无日期：'+link)
            day=datetime.strptime(stamp[1],'%Y%m%d').date()
            found.append(day)
            if day<=END:result.append(dict(date=day.isoformat(),event_type='FOMC',source_url=link,source_page=source,description=title))
        if year<=2019 and len(found)!=8:raise ValueError(f'{year} 年例行FOMC不是8场：{len(found)}，请核查')
    for key,kind in [('empsit','Nonfarm'),('ppi','PPI')]:
        source=f'https://www.bls.gov/bls/news-release/{key}.htm'
        text=(RAW/f'bls_{key}_archive.html').read_text(encoding='utf-8-sig')
        links=re.findall(r'href="([^"]*'+key+r'_(\d{8})\.(?:htm|pdf|txt))"',text,re.I)
        records={}
        for link,stamp in links:
            day=datetime.strptime(stamp,'%m%d%Y').date()
            if date(2004,1,1)<=day<=END:
                # Prefer HTML when both the HTML and PDF are listed.
                if day not in records or link.endswith('.htm'):records[day]=urljoin(source,html.unescape(link))
        for year in range(2004,2020):
            if sum(d.year==year for d in records)!=12:raise ValueError(f'{kind} {year} 发布日期数量不是12，需核查')
        for day,link in records.items():
            result.append(dict(date=day.isoformat(),event_type=kind,source_url=link,source_page=source,description='Actual release date from archived release URL'))
    result.sort(key=lambda r:(r['date'],r['event_type']))
    if len(result)!=len({(r['date'],r['event_type']) for r in result}):raise ValueError('事件重复')
    return result

def main():
    events=parse_events()
    save('macro_events.csv',['date','event_type','source_url','source_page','description'],events)
    with (ROOT/'vwret_标普500替代/sp500d.csv').open(encoding='utf-8-sig',newline='') as f:
        market=sorted(date.fromisoformat(r['caldt']) for r in csv.DictReader(f))
    if len(market)!=len(set(market)):raise ValueError('市场交易日历存在重复日期')
    months={m:i+1 for i,m in enumerate(['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'])}
    with (ROOT/'ARA.csv').open(encoding='utf-8-sig',newline='') as f:
        analysis=sorted(date(int(r['date'][5:]),months[r['date'][2:5].lower()],int(r['date'][:2])) for r in csv.DictReader(f))
    index={d:i for i,d in enumerate(market)}
    if not set(analysis)<=set(market):raise ValueError('ARA日期不在市场交易日历')
    needed_end=market[index[max(analysis)]+6]
    if needed_end>END:raise ValueError('事件收集区间不足以覆盖未来窗口')
    by_day={}
    for r in events:by_day.setdefault(date.fromisoformat(r['date']),set()).add(r['event_type'])
    nontrading=[r for r in events if date.fromisoformat(r['date']) not in index]
    save('nontrading_events.csv',['date','event_type','source_url','source_page','description'],nontrading)
    # Baseline: a release must occur on an actual trading date in the future window.
    # Do not silently move announcements on a closed market day to the next session.
    output=[];audit=[]
    for d in analysis:
        i=index[d];future=market[i+2:i+7]
        if len(future)!=5:raise ValueError('缺少未来交易日缓冲')
        hits=[x for x in future if x in by_day]
        output.append(dict(date=d.isoformat(),mnews26=int(bool(hits))))
        audit.append(dict(date=d.isoformat(),window_start=future[0].isoformat(),window_end=future[-1].isoformat(),event_dates=';'.join(x.isoformat() for x in hits),event_types=';'.join(sorted(set().union(*(by_day[x] for x in hits)))) if hits else ''))
    save('mnews26.csv',['date','mnews26'],output)
    save('window_audit.csv',['date','window_start','window_end','event_dates','event_types'],audit)
    counts=Counter((r['date'][:4],r['event_type']) for r in events)
    save('event_counts_by_year.csv',['year','FOMC','Nonfarm','PPI'],[dict(year=y,**{k:counts[(str(y),k)] for k in ['FOMC','Nonfarm','PPI']}) for y in range(2004,2021)])
    summary=dict(event_rows=len(events),analysis_rows=len(output),analysis_start=output[0]['date'],analysis_end=output[-1]['date'],news_rows=sum(r['mnews26'] for r in output),required_event_end=needed_end.isoformat(),nontrading_event_rows=len(nontrading),selection='Scheduled FOMC statements + actual BLS Nonfarm/PPI release dates; events on nontrading dates excluded from baseline and retained in audit; reconstructed, not author-supplied')
    (HERE/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False))

if __name__=='__main__':main()
