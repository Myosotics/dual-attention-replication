from urllib.request import Request,urlopen
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,hashlib
B=Path(__file__).resolve().parent
RAW=B/'raw';RAW.mkdir(exist_ok=True)
S=[(f'fomc_{y}.html',f'https://www.federalreserve.gov/monetarypolicy/fomchistorical{y}.htm') for y in range(2004,2021)]
S += [('bls_empsit_archive.html','https://www.bls.gov/bls/news-release/empsit.htm'),('bls_ppi_archive.html','https://www.bls.gov/bls/news-release/ppi.htm')]
def get(pair):
 name,url=pair;p=RAW/name
 try:
  if not p.exists():
   data=urlopen(Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=30).read();p.write_bytes(data)
  data=p.read_bytes()
  return dict(file=name,url=url,status='saved',bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
 except Exception as e:return dict(file=name,url=url,status='failed',error=str(e))
if __name__=='__main__':
 with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(get,S))
 (B/'source_manifest.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
 for r in results:print(r['file'],r['status'],r.get('bytes',r.get('error')))
