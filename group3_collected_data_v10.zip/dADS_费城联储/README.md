# dADS_费城联储

- 状态：**真实公开数据的计算列**。
- 来源：费城联储 ADS_Index；按原始日序列计算一阶差分。
- 来源地址：https://www.philadelphiafed.org/surveys-and-data/real-time-data-research/ads
- 原始文件：`ADS_Index_Most_Current_Vintage.xlsx`，已包含在本文件夹。
- 单指标输出：`dADS.csv`，列为 `date,dADS`，日期 ISO 格式。已预生成；需要时可重建：

```bash
python3 build.py
```

需要 pandas 和 openpyxl；安装方式见根目录 `requirements.txt`。 脚本不会联网，也不会用模拟值填缺口。

**使用边界：**这是当前最新版本数据；论文原始数据的 vintage/缺失处理仍需核对。
