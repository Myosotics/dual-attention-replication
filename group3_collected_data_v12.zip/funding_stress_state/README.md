# funding_stress_state：TED利差融资压力状态

## 采用理由与研究范围

TED利差为3个月美元LIBOR减3个月美国国库券利率，反映银行信用风险和融资压力。融资压力可能限制套利资金，因此用于Table 3的新增融资压力分组。它不是借股票卖空的费用，不能验证原高借贷费用组的−75.70bp，也不能称为原dfee的精确复现。

经member1确认，本分支取代原随机模拟借贷费用分组；独立模拟dfee已删除。回归应显式使用 `funding_stress_state`，结果标为“高／低融资压力”；不要将它无说明改名为dfee。VIX和有效价差分支不受此范围调整影响。本包只整理数据，未运行回归。

## 来源

- 提供方：Federal Reserve Bank of St. Louis，FRED，序列TEDRATE。
- 说明：https://fred.stlouisfed.org/series/TEDRATE
- 原始CSV下载：https://fred.stlouisfed.org/graph/fredgraph.csv?id=TEDRATE&cosd=2003-01-01&coed=2019-12-31
- 整理核验日期：2026-11-08。`TEDRATE_2003_2019.csv` 保留下载字节，不改原始缺失；SHA-256见包根目录清单。
- 引用：Federal Reserve Bank of St. Louis, TED Spread (DISCONTINUED) [TEDRATE], retrieved from FRED, https://fred.stlouisfed.org/series/TEDRATE 。该页标明引用要求；原始序列保留来源单位“Percent”，0.32表示0.32个百分点（32基点），不再乘100。
- 序列已停止更新，不影响2004—2019年研究。当前下载历史数据不等同逐日当时可得版本；未核对每个观测的实际发布时间或修订历史，不能据此宣称实时可交易。

## 为什么缺失？

TED依赖两个市场的利率报价，银行／伦敦利率市场与美国股市假期不一致，可能造成股市开盘但一项输入无报价。例如样本缺失集中于部分星期一，存在与银行假期吻合的日期。ICE的LIBOR假期日历也列有不发布报价日期：https://www.ice.com/publicdocs/LIBOR_Holiday_Calendar_2019.pdf 。

这是日历差异的合理解释，不是对每个缺失日的逐项确认；FRED CSV未提供逐日缺失原因。缺失不能解释为零利差。原始CSV有4,434个工作日日期行，其中4,173条有效值；合并ARA的3,903个股市交易日后有100个缺失（2.56%）。

## 默认填补与分组

1. 对目标交易日，保留当天有效原值；若缺失，仅向过去寻找最近一次有效值（forward fill）。
2. 设置7个自然日的最长沿用期限；超过则保留缺失，不无限延用，不用未来值插值或反向填补。7日是本方案预设容忍窗口，并非论文参数。
3. 本样本100个缺失均可补齐，实际沿用间隔最长5个自然日。沿用值不代表观测到当天真实利差。
4. 在固定ARA日历2004-07-01—2019-12-31上，按填补后TED的全样本中位数0.32分组：`funding_stress_state = 1(TEDRATE_used > 0.32)`；等于中位数归低组。高组1,936日，低组1,967日。
5. 同时保留严格不填补列 `funding_stress_state_no_fill`，按非缺失原值的中位数独立分组，本样本也为0.32；原缺失日留空。建议以此剔除100日后重估，作为敏感性比较。

分组中位数为上述固定全样本的描述性阈值，跨ARA/AIA可得子样本沿用同一阈值；不是实时信号。若按各自回归有效样本重新计算中位数，需另行明确报告，不能混用。无需套用股票借贷费用的“三个月相对异常值”公式。

## 文件与运行

| 文件 | 内容 |
|---|---|
| TEDRATE_2003_2019.csv | FRED原始下载，保留缺失 |
| build.py | 本地重建，仅用Python标准库，无需联网 |
| funding_stress_state.csv | 3,903行：date、TEDRATE_raw、TEDRATE_used、source_date、is_filled、age_days、默认分组与严格不填补分组 |
| missing_fill_audit.csv | 100个缺失交易日的沿用值、来源日期及间隔 |
| summary.json | 中位数、填补数、分组计数和固定样本范围 |

在包根目录运行：

```bash
python funding_stress_state/build.py
```

`is_filled=1`只表示原值缺失但成功沿用；`age_days`为目标日与原观测日间隔的自然日数。原始TED或严格分组缺失保持空单元格。推荐主结果采用默认短缺口沿用，另外报告不填补版本；如果两者结论差异较大，不能忽略填补影响。
