#!/usr/bin/env python3
"""从本地FRED TED利差构建融资压力状态；仅用Python标准库。"""
import csv
import json
from bisect import bisect_right
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from statistics import median

HERE = Path(__file__).resolve().parent
MAX_AGE_DAYS = 7


def main():
    with (HERE / 'TEDRATE_2003_2019.csv').open(encoding='utf-8-sig', newline='') as f:
        raw = list(csv.DictReader(f))
    dates = [date.fromisoformat(r['observation_date']) for r in raw]
    if dates != sorted(set(dates)):
        raise ValueError('原始日期重复或未排序')
    series = {d: (None if r['TEDRATE'].strip() in ('', '.') else Decimal(r['TEDRATE']))
              for d, r in zip(dates, raw)}
    if any(v is not None and not v.is_finite() for v in series.values()):
        raise ValueError('原始利差含非法数值')
    valid_dates = [d for d in dates if series[d] is not None]
    with (HERE.parent / 'ARA.csv').open(encoding='utf-8-sig', newline='') as f:
        targets = [datetime.strptime(r['date'], '%d%b%Y').date() for r in csv.DictReader(f)]
    if targets != sorted(set(targets)):
        raise ValueError('目标日历重复或未排序')
    rows = []
    for d in targets:
        v = series.get(d)
        i = bisect_right(valid_dates, d) - 1
        prior = valid_dates[i] if i >= 0 else None
        age = (d-prior).days if prior else None
        usable = prior is not None and age <= MAX_AGE_DAYS
        used = series[prior] if usable else None
        rows.append({'date': d.isoformat(), 'TEDRATE_raw': v,
                     'TEDRATE_used': used, 'source_date': prior.isoformat() if usable else '',
                     'is_filled': int(v is None and used is not None),
                     'age_days': age if usable else None})
    threshold = median([r['TEDRATE_used'] for r in rows if r['TEDRATE_used'] is not None])
    # 严格不填补版本独立计算中位数，用于敏感性比较。
    strict_threshold = median([r['TEDRATE_raw'] for r in rows if r['TEDRATE_raw'] is not None])
    for r in rows:
        r['funding_stress_state'] = (None if r['TEDRATE_used'] is None else int(r['TEDRATE_used'] > threshold))
        r['funding_stress_state_no_fill'] = (None if r['TEDRATE_raw'] is None else int(r['TEDRATE_raw'] > strict_threshold))
    fields = list(rows[0])
    def write(name, values):
        with (HERE / name).open('w', encoding='utf-8', newline='') as f:
            w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(values)
    write('funding_stress_state.csv', rows)
    write('missing_fill_audit.csv', [r for r in rows if r['TEDRATE_raw'] is None])
    summary = {'source': 'FRED TEDRATE', 'window': [targets[0].isoformat(), targets[-1].isoformat()],
               'rows': len(rows), 'raw_missing': sum(r['TEDRATE_raw'] is None for r in rows),
               'filled': sum(r['is_filled'] for r in rows),
               'remaining_missing': sum(r['TEDRATE_used'] is None for r in rows),
               'max_allowed_age_calendar_days': MAX_AGE_DAYS,
               'max_actual_fill_age_days': max(r['age_days'] for r in rows if r['is_filled']),
               'median_after_fill': str(threshold), 'median_no_fill': str(strict_threshold),
               'high_count': sum(r['funding_stress_state'] == 1 for r in rows),
               'low_count': sum(r['funding_stress_state'] == 0 for r in rows),
               'scope': '2004-07-01 to 2019-12-31 ARA calendar; fixed full-sample descriptive median, not real-time threshold'}
    (HERE / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == '__main__':
    main()
