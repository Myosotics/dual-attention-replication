# aia：模拟指标

状态：**模拟／模拟派生**。模拟 Bloomberg AIA，占位；有缺失日。真实 AIA 未取得。

当前文件 `aia_SIMULATED.csv` 已从同学的 `mixed_public_panel.csv` 按列提取；缺失保留空单元格，未补零。它不是真实实证数据，也不能用来声称复现论文系数或显著性。

重新生成：在本文件夹运行

```bash
python3 build.py
```

脚本调用同包 `../_共享生成器/` 中原同学项目的固定种子生成代码和公开原始文件，重新计算混合面板并只导出 `date,aia`。需要 `numpy、pandas、openpyxl`。如后来取得真实指标，请另存为新的真实数据文件，勿覆盖此模拟文件。
