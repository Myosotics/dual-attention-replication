# 模拟指标的共享生成器

此目录是同学 `第三组复现项目.zip` 中的原始模拟生成代码与运行所需公开输入，只用于重建下方各**模拟指标**。不代表作者真实数据。

- `src/generate_simulation.py`：固定随机种子 `20241107`，构造基础模拟面板。
- `src/build_mixed_public_panel.py`：用公开 ARA、VIX、ADS、BW、TMS、DFY 替换对应列，随后重新生成模拟的未来收益和交易变量。
- `supplement/datasubmission/ARA.csv` 与 `data/public/raw/`：代码的输入文件。

每个指标子文件夹的 `build.py` 都调用同一共享生成器，然后只写出该指标两列（日期和数值）。无需手动先运行共享脚本。运行依赖见根目录 `requirements.txt`。生成器会一次计算整个内部面板，但不会在指标目录输出其他变量。

**特别注意：**模拟 `fvwret5` 在原代码中单独由预设关系生成，**不是**由模拟 `vwret` 的 t+2 至 t+6 日收益复合计算。因此它不能与替代 `vwret.csv` 混用来声称已经算出真实市场未来收益。
