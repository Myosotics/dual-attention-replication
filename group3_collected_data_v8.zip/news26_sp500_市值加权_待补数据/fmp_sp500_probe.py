#!/usr/bin/env python3
"""FMP权限与历史覆盖测试：最多两次请求，不重建历史成员，不读取密钥文件。"""
import csv,json,os,sys,getpass,argparse
from pathlib import Path
from datetime import datetime,timezone
from urllib.request import Request,urlopen
from urllib.parse import urlencode
from urllib.error import HTTPError,URLError

BASE='https://financialmodelingprep.com/stable/'

def save_csv(path,rows):
    fields=list(dict.fromkeys(k for row in rows for k in row))
    if not fields:fields=['date','symbol','removedTicker']
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

def event_date(row):
    # Prefer the provider's date field; retain dateAdded separately in original files.
    s=str(row.get('date') or row.get('dateAdded') or '').strip()
    for fmt in ('%Y-%m-%d','%B %d, %Y','%b %d, %Y'):
        try:return datetime.strptime(s,fmt).date()
        except ValueError:pass
    return None

def request(endpoint,key,output,name):
    url=BASE+endpoint+'?'+urlencode({'apikey':key})
    status=None
    try:
        req=Request(url,headers={'User-Agent':'FMP-SP500-Research-Probe/1.0','Accept':'application/json'})
        with urlopen(req,timeout=40) as r:
            status=r.status;text=r.read().decode('utf-8-sig').replace(key,'[REDACTED]')
    except HTTPError as e:
        status=e.code;text=e.read().decode('utf-8',errors='replace').replace(key,'[REDACTED]')
    except URLError as e:
        reason=str(e.reason).replace(key,'[REDACTED]')
        print(f'{name}：连接失败：{reason}')
        return None,{'status':'connection_failed','reason':reason}
    try:payload=json.loads(text)
    except json.JSONDecodeError:
        (output/(name+'_response.txt')).write_text(text,encoding='utf-8')
        print(f'{name}：返回非JSON内容，HTTP {status}，已保存供核查。')
        return None,{'http_status':status,'status':'non_json'}
    (output/(name+'_raw.json')).write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    if status!=200 or not isinstance(payload,list) or not all(isinstance(x,dict) for x in payload):
        print(f'{name}：未取得记录列表，HTTP {status}。查看对应 raw.json 的权限／错误提示。')
        return None,{'http_status':status,'status':'not_record_list'}
    save_csv(output/(name+'.csv'),payload)
    print(f'{name}：成功返回 {len(payload)} 条记录。')
    return payload,{'http_status':status,'status':'returned_list','rows':len(payload)}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'fmp_probe_output')
    args=parser.parse_args()
    key=os.environ.get('FMP_API_KEY','').strip()
    if not key:
        if not sys.stdin.isatty():raise SystemExit('非交互环境请通过 FMP_API_KEY 环境变量提供密钥，或在本地终端运行。')
        key=getpass.getpass('请输入你的 FMP API key（不显示、不保存）：').strip()
    if not key:raise SystemExit('API key 为空，未发出请求。')
    now=datetime.now(timezone.utc)
    output=args.output/now.strftime('%Y%m%d_%H%M%S_%f_UTC');output.mkdir(parents=True,exist_ok=False)
    history,hstatus=request('historical-sp500-constituent',key,output,'historical_changes_all')
    current,cstatus=request('sp500-constituent',key,output,'current_constituents_snapshot')
    summary={'retrieved_at_utc':now.isoformat(),'historical_endpoint':BASE+'historical-sp500-constituent','current_endpoint':BASE+'sp500-constituent','history':hstatus,'current_snapshot':cstatus,'note':'Returned records do not certify completeness. Current snapshot is an anchor, not historical membership.'}
    if history is not None:
        parsed=[(row,event_date(row)) for row in history]
        valid=[(r,d) for r,d in parsed if d is not None]
        target=[r for r,d in valid if 2010<=d.year<=2019]
        save_csv(output/'historical_changes_2010_2019.csv',target)
        issues=[r for r,d in parsed if d is None]
        save_csv(output/'date_parse_issues.csv',issues)
        years={str(y):sum(d.year==y for _,d in valid) for y in range(2010,2020)}
        summary['historical_date_check']={'earliest':min((d.isoformat() for _,d in valid),default=None),'latest':max((d.isoformat() for _,d in valid),default=None),'rows_2010_2019':len(target),'rows_by_year':years,'unparsed_rows':len(issues)}
        print('2010—2019年变动记录：',len(target))
        print('各年记录数：',years)
        print('无法解析日期的记录：',len(issues))
        if not target:print('注意：尚未取得目标年份记录，不能用于当前样本。')
        else:print('已取得目标年份的变动记录；仍需核对是否截断、是否有漏项、日期是否为生效日。')
    (output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print('\n保存目录：',output)
    print('请提供 summary.json 和历史变动 CSV；若报权限错误，可提供已脱敏的 raw.json。不要发送API key。')
    print('保留历史全量文件：重建2010—2019成员还需2019年至名单基准时点之间的变动，不能只保留目标年份切片。')

if __name__=='__main__':main()
