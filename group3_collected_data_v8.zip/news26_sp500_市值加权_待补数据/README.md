# All News：当期 S&P 500 成分股、市值加权（待补输入）

按 member1 的选择，保留市值加权，不改成等权。当前已完成构造代码、输入模板和下载渠道整理，**尚未生成真实 news26.csv**。原模拟 news26 仍单独保留，不能认为已被本目录替换。本目录是待补数据的工作材料，不计入已完成指标数量。

## 定义

令 S(d) 为日期d实际有效的S&P500证券集合，E(d)为当天发布财报的公司集合，MC(i,d)为证券i当日总市值：

`ann_ratio(d) = Σ[i∈S(d), company(i,d)∈E(d)] MC(i,d) / Σ[i∈S(d)] MC(i,d)`

`earnings_news(d) = 1{ann_ratio(d) > 当前分析样本 ann_ratio 的95%分位数}`

`news26(t) = max(mnews26(t), earnings_news(t+2), ..., earnings_news(t+6))`

使用当期有效成分区间和有效期内公司映射；不能将今天的名单回填历史。双重股权证券按各自证券市值计入分母，公司公告在其当期有效股类上共同匹配，不能给每个股类重复赋整个公司市值。此处使用证券总市值而非自由流通调整指数权重。分位阈值按当前样本重新计算，不套论文5.86%或5.95%。严格大于线性95%分位数，遇到并列值可能并非恰好5%的日期，和Stata xtile的并列规则需区分。

这沿用论文的市值占比与未来窗口逻辑，但股票范围限于当期S&P500，不是原论文整个CRSP市场。公告日使用实际财报发布日期，不直接使用10-Q/10-K提交日期；盘后公告不自动挪日，非交易日公告不顺延，保持当前宏观事件的按日期基准规则。后续可另做交易时段敏感性分析。

## 目前缺哪些数据、怎样获取

建议先看学校是否已有 WRDS 的 CRSP、Compustat/CCM 权限。机构订阅后，通常不需要个人另行购买；这些服务本身并非无条件免费。本次没有替你登录或购买数据库。

| 下载文件 | 最少字段 | 渠道和选择方式 | 用途 |
|---|---|---|---|
| `wrds_exports/members.csv` | `permno,start,ending` | WRDS→CRSP→S&P500历史成分列表；官方入口 https://wrds-www.wharton.upenn.edu/pages/grid-items/downloading-the-sp-500-constituents/ ，教学入口 https://wrds-www.wharton.upenn.edu/classroom/the-sp-500/ 。选取成员区间与2010-02-01至2019-10-14有交集的全部证券，包含后续退市和被移除公司。 | 当期证券集合，不能只导出最新名单。 |
| `wrds_exports/stocks.csv` | `permno,date,prc,shrout` | WRDS→CRSP→Stock/Security Files→Daily。对历史成分股并集导出2010-02-01至2019-10-14日价格和股数。CRSP旧格式市值计算为 `abs(prc)×shrout×1000`，shrout按千股，不能混用复权价格和未复权股数。 | 当日分子和分母的证券总市值；缺任一有效成分的市值，代码会停止而非缩小分母。 |
| `wrds_exports/fundq.csv` | `gvkey,datadate,rdq` | WRDS→Compustat North America→Fundamentals Quarterly，建议 INDL/STD/D/C，保留真实 `rdq`（季度盈利发布日期）；取覆盖2009年初至2020年1月公告的记录，季度末范围可放宽至2008年。筛选要针对全部历史成员对应公司，不只现存公司。入口 https://wrds-www.wharton.upenn.edu/ 。也可从有权限的I/B/E/S实际盈利公告日期获取，但需另行规范字段。 | 财报发布日期；财季末 datadate 不能替代 rdq。 |
| `wrds_exports/links.csv` | `lpermno,gvkey,linkdt,linkenddt,linktype,linkprim` | WRDS→CRSP/Compustat Merged→Link Table（常见旧表 `ccmxpf_linktable`）。导出成员PERMNO的历史链接，保留有效起止日。 | 按有效日期把证券与公告公司对应，避免名称、股票代码重用与更名错误。 |

以上为旧CRSP字段格式模板。你若导出新版CIZ/指数v2字段，保留原始列再提供给整理人员，不要猜字段；例如 v2 成分区间常用 `mbrstartdt,mbrenddt`，需按数据字典映射。证券PERMNO和公司GVKEY按字符串保存。

**最容易的下一步：把上表4份原始CSV导出即可，再由我们检查规范字段。** 不需要你手工为每天数百家公司计算市值。若已拿到日度证券市值列，可直接提供 `date,security_id,market_cap`，跳过价格股数相乘。金额统一单位，无需金额规模正好匹配论文。

## 免费候选来源的实际核验

本次下载并检查了公开历史名单和SEC衍生财报数据，但未把它们当成完整当期加权数据。结果见 `候选来源核验.csv`，链接见 `source_links.csv`。

- hanshof/sp500_constituents 的历史名单在2010—2020年初观察到444—499个代码，且是稀疏快照，不是每个交易日；不能无核验地声称完整覆盖当时S&P500证券。
- FinzData公开样本共227,753条SEC衍生财报记录、4,308个CIK，含report_date、filed等字段；但未找到AET、CELG、TWX、MON、AGN等历史成员。按原始ticker与候选名单的粗略年内匹配，仅约59%（2010年初名单）至73%（2019年初名单）；此数仅用于发现覆盖风险，不是最终准确率。
- 股票代码可能已更名或被重用，不能只做代码字符串连接。SEC 8-K封面report_date表示最早相关事件日期，不保证就是财报发布日期；需核对Item2.02正文或财报新闻稿。官方规则 https://www.sec.gov/divisions/corpfin/forms/8-k.htm 。
- 本次未找到可免费直接下载、完整覆盖所有历史成员的2010—2019年日度市值。今天的市值、今天的股数乘历史价格、删除无数据的退市股都不能满足本方案。

因此本次不生成一个看似完整的加权结果。若学校无数据库权限，可用SEC公开档案逐公司补真实公告与历史股数，并获取相同口径价格；但对历史退市公司和代码映射仍需大量核验，不能保证省事。候选来源不完整，不建议直接用于定稿。

## 代码与运行

`prepare_wrds.py` 把4个下载文件转成 inputs/ 内的3张标准表：

- `membership.csv`：`security_id,company_id,start_date,end_date`，区间含首尾日；必须覆盖分析期及末端6个交易日。
- `daily_marketcap.csv`：`date,security_id,market_cap`，当日证券总市值、统一货币单位。
- `earnings.csv`：`announcement_date,company_id`，实际财报公告日，同公司同日去重。

目录里的CSV目前只有表头，是待填模板，不是实际数据。输入完善后：

```bash
python3 prepare_wrds.py --start 2010-02-01 --buffer-end 2019-10-14
python3 build.py --start 2010-02-01 --end 2019-10-04 --confirm-earnings-coverage
```

需要 pandas、numpy，见数据包根目录requirements.txt。财报覆盖确认参数表示已核对数据源覆盖当期所有公司；它不能代替实际核查，也不代表代码能自动识别全部漏报。代码会检查日期区间、重复证券、市值缺失、公司映射、至少450个当期证券及完全无财报记录的成员。记录缺失不能自动解释为“无公告”。

成功后输出 `news26.csv`、`ann_ratio_audit.csv`、`window_audit.csv`、`summary.json`。缺实际输入时直接报错，不写模拟填充结果。代码从同包市场原始日期构造交易日历，合并已完成的 mnews26，保证 news26 至少包含 mnews26。2019-10-04分析日需要输入覆盖到2019-10-14；以后扩展样本时相应扩展所有历史成员、市值和公告输入。


## FMP历史成分入口：先测试账号是否能取得数据

官方历史接口说明：https://site.financialmodelingprep.com/developer/docs/stable/historical-sp-500 ，当前名单接口说明：https://site.financialmodelingprep.com/developer/docs/stable/sp-500 。注册FMP账号后，在本地使用自己的key测试；不同套餐的历史深度、股票范围和接口权限可能不同，本脚本不承诺免费账号一定可取。

脚本 `fmp_sp500_probe.py` 只用Python标准库，最多请求两次，不需要pandas。在本文件夹打开终端运行：

```bash
python3 fmp_sp500_probe.py
```

按提示粘贴本地API key（输入时不显示字符是正常的），不要把key发到聊天或上传GitHub。也可以在本地通过 FMP_API_KEY 环境变量提供；不要将含密钥的命令或链接公开。

输出位于脚本旁的 `fmp_probe_output/时间戳/`。包括历史变动全量JSON与CSV、2010—2019切片、无法解析日期的记录、当前名单快照和 summary.json。历史接口失败后仍会尝试当前名单，错误响应脱敏保存，便于检查账号权限。401/403/402可能涉及认证或权限，429可能是限流，应以实际返回正文为准；不循环重试、不购买套餐。

回传 summary.json 和取得的历史CSV即可；报错可发已脱敏raw.json。全量历史记录也要保留：若以当前名单向前倒推，必须处理2019年之后直到名单快照时点的变动。变动日期需核对实际生效日，单有“2010—2019有记录”不等于历史完整，也不能据此宣称已重建当期成分股。本脚本只测试成分信息，不获取市值或财报日期，不生成All News。

当前代码已用本地模拟HTTP响应检验保存、日期解析和错误脱敏；未使用真实FMP账号测试。成功下载后再决定如何接入市值加权工作流。
