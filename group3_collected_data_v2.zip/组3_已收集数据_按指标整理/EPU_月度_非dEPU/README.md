# EPU_月度_非dEPU

- 状态：**真实公开月度数据，但不是论文日度 ΔEPU**。
- 来源：政策不确定性网站 US 月度 News-Based Policy Uncertainty Index。
- 来源地址：https://www.policyuncertainty.com/media/US_Policy_Uncertainty_Data.csv
- 原始文件：`EPU_US_Monthly.csv`，已包含在本文件夹。
- 单指标输出：`EPU_monthly.csv`，列为 `date,EPU_monthly`，日期 ISO 格式。已预生成；需要时可重建：

```bash
python3 build.py
```

本脚本仅使用 Python 3 标准库。 脚本不会联网，也不会用模拟值填缺口。

**使用边界：**不能用月度数据填充日度 ΔEPU。
