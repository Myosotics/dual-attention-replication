#!/usr/bin/env python3
"""按原同学项目代码重建此模拟指标；输出仍是模拟数据。"""
from __future__ import annotations
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
COMMON = HERE.parent / '_共享生成器'
sys.path.insert(0, str(COMMON / 'src'))
from build_mixed_public_panel import build_mixed_panel

COLUMN = 'dfee'
OUTPUT = HERE / 'dfee_SIMULATED.csv'

def main():
    panel, metadata = build_mixed_panel(public_dir=COMMON / 'data/public/raw')
    if metadata['classification'] != 'MIXED PUBLIC/SIMULATED - NOT AN EXACT REPLICATION':
        raise RuntimeError('来源面板标签异常')
    panel[['date', COLUMN]].to_csv(OUTPUT, index=False, date_format='%Y-%m-%d')
    print(f'重建 {OUTPUT.name}：{len(panel)} 个日期；该列为模拟或模拟派生，不能作论文原始数据')

if __name__ == '__main__':
    main()
