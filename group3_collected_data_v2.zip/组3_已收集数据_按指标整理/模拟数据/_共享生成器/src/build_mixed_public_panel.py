#!/usr/bin/env python3
"""Merge verified public data into the Group 3 simulation demonstration.

The result is deliberately called a mixed panel: public real data are used
where available, while licensed or proprietary inputs remain simulated.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

from generate_simulation import DEFAULT_OUTPUT, SEED, generate_panel


ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "public" / "raw"
DEFAULT_OUTPUT = ROOT / "data" / "mixed_public_panel.csv"
DEFAULT_METADATA = ROOT / "output" / "mixed_public_metadata.json"
LABEL = "MIXED PUBLIC/SIMULATED - NOT AN EXACT REPLICATION"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _monthly_dates(frame: pd.DataFrame) -> pd.DataFrame:
    result = frame.copy()
    result["date"] = pd.to_datetime(
        result["yearmo"].astype(int).astype(str),
        format="%Y%m",
    ) + pd.offsets.MonthBegin(0)
    return result.sort_values("date")


def _asof_monthly(
    daily: pd.DataFrame, monthly: pd.DataFrame, columns: list[str]
) -> pd.DataFrame:
    merged = pd.merge_asof(
        daily.sort_values("date"),
        monthly[["date", *columns]].sort_values("date"),
        on="date",
        direction="backward",
        allow_exact_matches=True,
    )
    return merged


def build_mixed_panel(
    public_dir: Path = RAW,
    seed: int = SEED,
) -> tuple[pd.DataFrame, dict]:
    # Start from the deterministic DGP for variables that remain proprietary.
    panel, base_metadata = generate_panel(seed=seed)
    panel = panel.sort_values("date").reset_index(drop=True)

    ara_path = public_dir / "author_attention" / "ARA.csv"
    ara = pd.read_csv(ara_path)
    ara["date"] = pd.to_datetime(ara["date"], format="%d%b%Y", errors="raise")
    ara = ara.rename(columns={"ara": "ara_public"})
    panel = panel.merge(
        ara[["date", "ara_public"]], on="date", how="left", validate="one_to_one"
    )
    if panel["ara_public"].isna().any():
        raise RuntimeError("Author ARA data do not cover the panel dates")
    panel["ara"] = panel["ara_public"]
    panel = panel.drop(columns="ara_public")

    vix_path = public_dir / "VIX_History.csv"
    vix = pd.read_csv(vix_path)
    vix["date"] = pd.to_datetime(vix["DATE"], format="%m/%d/%Y", errors="raise")
    vix = vix[["date", "CLOSE"]].rename(columns={"CLOSE": "VIX_public"})
    panel = panel.merge(vix, on="date", how="left", validate="one_to_one")
    panel["VIX"] = panel["VIX_public"].ffill()
    panel = panel.drop(columns="VIX_public")
    if panel["VIX"].isna().any():
        raise RuntimeError("Cboe VIX data could not be aligned")

    ads_path = public_dir / "ADS_Index_Most_Current_Vintage.xlsx"
    ads = pd.read_excel(ads_path)
    ads["date"] = pd.to_datetime(
        ads["Date"].astype(str).str.replace(":", "-", regex=False),
        errors="raise",
    )
    ads_series = (
        ads.set_index("date")["ADS_Index"].sort_index().astype(float)
    )
    panel["ADS_public"] = panel["date"].map(ads_series)
    panel["dADS"] = panel["date"].map(ads_series.diff())
    if panel["dADS"].isna().any():
        raise RuntimeError("ADS public data could not supply dADS")

    predictors_path = public_dir / "Goyal_Welch_AllData_Monthly.csv"
    predictors = pd.read_csv(predictors_path)
    predictors["yearmo"] = pd.to_numeric(predictors["yyyymm"], errors="coerce")
    predictors = predictors[
        predictors["yearmo"].between(200401, 201912)
    ].copy()
    for column in ("tms", "dfy"):
        predictors[column] = pd.to_numeric(predictors[column], errors="coerce")
    predictors["tms_public"] = predictors["tms"] * 100.0
    predictors["dfy_public"] = predictors["dfy"] * 100.0
    predictors["date"] = pd.to_datetime(
        predictors["yearmo"].astype(int).astype(str), format="%Y%m"
    ) + pd.offsets.MonthBegin(0)
    panel = _asof_monthly(
        panel,
        predictors,
        ["tms_public", "dfy_public"],
    )
    panel["tms"] = panel["tms_public"]
    panel["dfy"] = panel["dfy_public"]
    panel = panel.drop(columns=["tms_public", "dfy_public"])

    sentiment_path = public_dir / "Baker_Wurgler_SENTIMENT.xlsx"
    sentiment = pd.read_excel(sentiment_path, sheet_name="DATA")
    sentiment = _monthly_dates(sentiment)
    sentiment["lBWx_public"] = sentiment["SENT"].shift(1)
    panel = _asof_monthly(
        panel,
        sentiment,
        ["SENT", "SENT_ORTH", "lBWx_public"],
    )
    panel = panel.rename(
        columns={"SENT": "BW_SENT_public", "SENT_ORTH": "BW_SENT_ORTH_public"}
    )
    panel["lBWx"] = panel["lBWx_public"].ffill()
    if panel["lBWx"].isna().any():
        raise RuntimeError("Wurgler sentiment data could not supply lBWx")

    # The official policy-uncertainty site provides a public daily seven-day
    # moving average. It is retained as related evidence, but is not substituted
    # for the paper's raw USEPUINDXD series.
    epu_ma_path = public_dir / "EPU_Daily_7day_MA.csv"
    epu_ma = pd.read_csv(epu_ma_path)
    epu_ma["date"] = pd.to_datetime(
        dict(year=epu_ma["year"], month=epu_ma["month"], day=epu_ma["day"]),
        errors="raise",
    )
    epu_ma = epu_ma[["date", "daily_policy_moving_average"]].rename(
        columns={"daily_policy_moving_average": "EPU_MA7_public"}
    )
    panel = panel.merge(epu_ma, on="date", how="left", validate="one_to_one")
    panel["EPU_MA7_public"] = panel["EPU_MA7_public"].ffill()
    panel["dEPU_MA7_public"] = panel["EPU_MA7_public"].diff()

    raw_epu_path = public_dir / "USEPUINDXD.csv"
    d_epu_source = "SIMULATED"
    if raw_epu_path.exists() and raw_epu_path.stat().st_size > 100:
        raw_epu = pd.read_csv(raw_epu_path)
        date_column = raw_epu.columns[0]
        value_column = raw_epu.columns[1]
        raw_epu["date"] = pd.to_datetime(raw_epu[date_column], errors="raise")
        raw_epu = raw_epu[["date", value_column]].rename(
            columns={value_column: "EPU_public"}
        )
        panel = panel.merge(raw_epu, on="date", how="left", validate="one_to_one")
        panel["EPU_public"] = panel["EPU_public"].ffill()
        raw_d_epu = panel["EPU_public"].diff()
        if raw_d_epu.notna().any():
            panel["dEPU"] = raw_d_epu
            d_epu_source = "PUBLIC"

    vix_full = (
        pd.read_csv(vix_path)
        .assign(
            date=lambda frame: pd.to_datetime(
                frame["DATE"], format="%m/%d/%Y", errors="raise"
            )
        )
        .set_index("date")["CLOSE"]
        .sort_index()
        .astype(float)
    )
    for lag in range(1, 5):
        prefix = "l" if lag == 1 else f"l{lag}"
        panel[f"{prefix}VIX"] = panel["date"].map(vix_full.shift(lag))

    # Rebuild the synthetic outcome using public controls where available.
    high_vix = (panel["VIX"] > 15.57).astype(float)
    high_spread = (panel["percentspread"] > 0.0005239).astype(float)
    high_fee = panel["dfee"].fillna(0.0)
    aia_zero = panel["aia"].fillna(0.0)
    ara_effect = (
        -3.0
        - 2.0 * high_vix
        - 2.0 * high_spread
        - 12.0 * high_fee
    )
    news_effect = 2.0 * aia_zero * panel["news26"]
    aia_state_effect = (
        (0.35 * high_vix + 0.10 * high_spread)
        * aia_zero
        * panel["news26"]
    )
    structural = (
        0.03
        + ara_effect * panel["ara"]
        + news_effect
        + aia_state_effect
        + 0.04 * panel["VIX"]
        - 0.04 * panel["tms"]
        - 0.10 * panel["dfy"]
        + 0.10 * panel["abn_news"]
        - 0.20 * panel["lBWx"]
        - 1.00 * panel["dADS"]
        + 0.001 * panel["dEPU"]
        - 0.10 * panel["abnto"]
    )
    outcome_rng = np.random.default_rng(seed + 100)
    panel["fvwret5"] = structural + outcome_rng.normal(scale=1.35, size=len(panel))

    retail_mask = panel["date"] >= pd.Timestamp("2010-01-04")
    negative = panel["vwret"] < 0
    bottom_roi = panel["vwret"] < -1.548332
    bottom_fund = panel["vwret"] < -1.856066
    retail_rng = np.random.default_rng(seed + 200)
    panel.loc[retail_mask, "retail_bhjos_vol"] = (
        3.555 * panel.loc[retail_mask, "ara"]
        + 3.4 * panel.loc[retail_mask, "ara"] * negative.loc[retail_mask]
        + 6.9 * panel.loc[retail_mask, "ara"] * bottom_roi.loc[retail_mask]
        + retail_rng.normal(scale=0.12, size=int(retail_mask.sum()))
    )
    panel.loc[retail_mask, "retail_bhjos_vol2"] = (
        0.237 * panel.loc[retail_mask, "ara"]
        + 0.17 * panel.loc[retail_mask, "ara"] * negative.loc[retail_mask]
        + 0.19 * panel.loc[retail_mask, "ara"] * bottom_roi.loc[retail_mask]
        + retail_rng.normal(scale=0.012, size=int(retail_mask.sum()))
    )
    fund_mask = panel["date"].between("2004-07-01", "2016-07-31")
    panel.loc[fund_mask, "equityflow"] = (
        0.187 * panel.loc[fund_mask, "ara"]
        + 0.02 * panel.loc[fund_mask, "ara"] * bottom_fund.loc[fund_mask]
        + retail_rng.normal(scale=0.008, size=int(fund_mask.sum()))
    )
    panel.loc[retail_mask, "ins_oib"] = (
        0.376 * panel.loc[retail_mask, "aia"]
        + 0.879 * panel.loc[retail_mask, "aia"] * panel.loc[retail_mask, "mnews26"]
        + retail_rng.normal(scale=0.025, size=int(retail_mask.sum()))
    )

    sources = {
        "ara": "PUBLIC AUTHOR DATA",
        "VIX": "PUBLIC CBOE",
        "dEPU": d_epu_source,
        "dADS": "PUBLIC PHILADELPHIA FED",
        "lBWx": "PUBLIC WURGLER; APPROXIMATE ONE-MONTH LAG MAPPING",
        "tms": "PUBLIC GOYAL-WELCH; lty-tbl",
        "dfy": "PUBLIC GOYAL-WELCH; BAA-AAA",
        "aia": "SIMULATED: BLOOMBERG DMR IS PROPRIETARY",
        "vwret": "SIMULATED: CRSP LICENSE REQUIRED",
        "abnto": "SIMULATED: CRSP STOCK-LEVEL DATA REQUIRED",
        "abn_news": "SIMULATED: RAVENPACK LICENSE REQUIRED",
        "percentspread": "SIMULATED: CRSP STOCK-LEVEL DATA REQUIRED",
        "dfee": "SIMULATED: DATA EXPLORERS REQUIRED",
        "mnews26": "SIMULATED EVENT WINDOWS",
        "news26": "SIMULATED EVENT WINDOWS",
        "retail_bhjos_vol": "SIMULATED: TAQ REQUIRED",
        "retail_bhjos_vol2": "SIMULATED: TAQ REQUIRED",
        "equityflow": "SIMULATED: TRIMTAB REQUIRED",
        "ins_oib": "SIMULATED: TAQ REQUIRED",
        "fvwret5": "SIMULATED DGP USING AVAILABLE CONTROLS",
    }
    files = []
    for path in sorted(public_dir.iterdir()):
        if path.is_file():
            files.append(
                {"file": path.name, "bytes": path.stat().st_size, "sha256": _sha256(path)}
            )
    metadata = {
        **base_metadata,
        "classification": LABEL,
        "seed": seed,
        "n_rows": int(len(panel)),
        "n_aia": int(panel["aia"].notna().sum()),
        "ara_stats": {
            "mean": float(panel["ara"].mean()),
            "std": float(panel["ara"].std()),
            "lag1": float(panel["ara"].autocorr(1)),
        },
        "aia_stats": {
            "mean": float(panel["aia"].mean()),
            "std": float(panel["aia"].std()),
            "min": float(panel["aia"].min()),
            "max": float(panel["aia"].max()),
        },
        "counts": {
            "high_vix": int((panel["VIX"] > 15.57).sum()),
            "low_vix": int((panel["VIX"] <= 15.57).sum()),
            "high_spread": int((panel["percentspread"] > 0.0005239).sum()),
            "low_spread": int((panel["percentspread"] <= 0.0005239).sum()),
            "high_fee": int((panel["dfee"] == 1).sum()),
            "low_fee": int((panel["dfee"] == 0).sum()),
            "macro_news": int((panel["mnews26"] == 1).sum()),
            "all_news": int((panel["news26"] == 1).sum()),
        },
        "public_stats": {
            "VIX": {
                "mean": float(panel["VIX"].mean()),
                "std": float(panel["VIX"].std()),
                "min": float(panel["VIX"].min()),
                "max": float(panel["VIX"].max()),
            },
            "dADS": {
                "mean": float(panel["dADS"].mean()),
                "std": float(panel["dADS"].std()),
            },
            "tms": {
                "mean": float(panel["tms"].mean()),
                "std": float(panel["tms"].std()),
            },
            "dfy": {
                "mean": float(panel["dfy"].mean()),
                "std": float(panel["dfy"].std()),
            },
            "lBWx": {
                "mean": float(panel["lBWx"].mean()),
                "std": float(panel["lBWx"].std()),
            },
        },
        "variable_sources": sources,
        "source_files": files,
        "source_urls": {
            "author_page": "https://sites.google.com/view/timcchung",
            "author_data_page": "https://sites.google.com/site/linpengbaruch/data",
            "author_attention_archive": (
                "https://www.dropbox.com/scl/fo/xpi0irqtlnxq6rbre06k5/"
                "AH-eVcrOnGbSKMSBdSG0nEA?rlkey=y61un7nk0j45bny0z0yb8b4np"
            ),
            "VIX": "https://cdn.cboe.com/api/global/us_indices/daily_prices/VIX_History.csv",
            "EPU_FRED": (
                "https://fred.stlouisfed.org/graph/fredgraph.csv?id=USEPUINDXD"
            ),
            "EPU_DAILY_MA": (
                "https://www.policyuncertainty.com/media/"
                "Daily_Policy_Moving_Average.csv"
            ),
            "EPU_US_MONTHLY": (
                "https://www.policyuncertainty.com/media/"
                "US_Policy_Uncertainty_Data.csv"
            ),
            "ADS": (
                "https://www.philadelphiafed.org/surveys-and-data/"
                "real-time-data-research/ads"
            ),
            "Wurgler": "https://www.stern.nyu.edu/~jwurgler/data/SENTIMENT.xlsx",
            "Goyal_Welch": (
                "https://docs.google.com/spreadsheets/d/"
                "17mw_IpaiLFDrGnrPRQ2o1ugV5nJsZuD1/"
                "gviz/tq?tqx=out:csv&sheet=Monthly"
            ),
        },
        "dgp": (
            "fvwret5_t = 0.03 + [-3 - 2*HighVIX - 2*HighSpread "
            "- 12*HighFee]*ARA_t + 2*AIA_t*News_t "
            "+ (0.35*HighVIX + 0.10*HighSpread)*AIA_t*News_t "
            "+ 0.04*VIX_t - 0.04*TMS_t - 0.10*DFY_t "
            "+ 0.10*AbnNews_t - 0.20*lBWx_t - 1.00*dADS_t "
            "+ 0.001*dEPU_t - 0.10*AbnTurn_t + epsilon_t, "
            "epsilon ~ N(0,1.35^2)"
        ),
        "search_notes": [
            "通过共同作者 Tim Hung 的公开主页定位到 Lin Peng 的聚合注意力数据页。",
            "作者公开压缩包只包含 ARA.csv 和 README，没有 AIA.csv。",
            "作者 README 明确说明 AIA 需要 Bloomberg 专有 DMR，因此 AIA 仍为模拟值。",
            "Cboe、费城联储、Wurgler 和 Goyal-Welch 的公开文件已成功下载并用于混合面板。",
            "FRED 原始日度 USEPUINDXD 多次返回空响应；官方日度7日均值另行保存，未将其冒充原始 EPU。",
        ],
    }
    return panel, metadata


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--public-dir", type=Path, default=RAW)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--metadata", type=Path, default=DEFAULT_METADATA)
    args = parser.parse_args()

    panel, metadata = build_mixed_panel(args.public_dir, seed=SEED)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.metadata.parent.mkdir(parents=True, exist_ok=True)
    processed_dir = args.public_dir / ".." / "processed"
    processed_dir.mkdir(parents=True, exist_ok=True)
    panel.to_csv(args.output, index=False)
    args.metadata.write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (processed_dir / "source_manifest.json").write_text(
        json.dumps(
            {
                "classification": metadata["classification"],
                "retrieved_date": "2026-11-07",
                "source_urls": metadata["source_urls"],
                "source_files": metadata["source_files"],
                "search_notes": metadata["search_notes"],
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    print(f"Mixed panel written to {args.output}")
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

