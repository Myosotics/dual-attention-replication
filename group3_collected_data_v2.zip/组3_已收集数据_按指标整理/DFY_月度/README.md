# DFY_月度

- 状态：**真实公开月度数据的计算列**。
- 来源：Goyal-Welch 月度表 dfy × 100；单位为百分点。
- 来源地址：https://docs.google.com/spreadsheets/d/17mw_IpaiLFDrGnrPRQ2o1ugV5nJsZuD1/gviz/tq?tqx=out:csv&sheet=Monthly
- 原始文件：`Goyal_Welch_AllData_Monthly.csv`，已包含在本文件夹。
- 单指标输出：`DFY_monthly.csv`，列为 `date,dfy`，日期 ISO 格式。已预生成；需要时可重建：

```bash
python3 build.py
```

本脚本仅使用 Python 3 标准库。 脚本不会联网，也不会用模拟值填缺口。

**使用边界：**输出仍是月度数据。合并日度回归前须确定论文采用的公布时间与滞后规则，不能直接把当月值当作月初已知。

额外保留同学数据包中的 `参考_原始变量表_Goyal_Welch_PredictorData.csv` 作为参考底表；本脚本不读取它，避免混用两个来源版本。
