# EPU_日度7日移动平均_非dEPU

- 状态：**真实公开数据，但不是论文 ΔEPU**。
- 来源：政策不确定性网站日度 7 日移动平均。
- 来源地址：https://www.policyuncertainty.com/media/Daily_Policy_Moving_Average.csv
- 原始文件：`EPU_Daily_7day_MA.csv`，已包含在本文件夹。
- 单指标输出：`EPU_MA7_daily.csv`，列为 `date,EPU_MA7`，日期 ISO 格式。已预生成；需要时可重建：

```bash
python3 build.py
```

本脚本仅使用 Python 3 标准库。 脚本不会联网，也不会用模拟值填缺口。

**使用边界：**不要将此列或其差分直接命名为论文 dEPU；原始日度 EPU 仍未获得。
