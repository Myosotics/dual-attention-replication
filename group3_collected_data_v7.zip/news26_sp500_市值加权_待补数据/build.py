#!/usr/bin/env python3
"""Construct a cap-weighted All News window from dated S&P500 membership."""
from pathlib import Path
import argparse,json
import pandas as pd
import numpy as np
HERE=Path(__file__).resolve().parent

def load(path,columns):
    frame=pd.read_csv(path,dtype=str)
    missing=set(columns)-set(frame.columns)
    if missing:raise ValueError(f'{path.name} 缺列 {sorted(missing)}')
    if frame.empty:raise ValueError(f'{path.name} 尚未填入实际数据')
    if frame[columns].isna().any().any():raise ValueError(f'{path.name} 必需列缺失')
    return frame

def construct(members,caps,earnings,calendar,macro,start,end,min_securities=450):
    members=members.copy();caps=caps.copy();earnings=earnings.copy()
    for c in ['start_date','end_date']:members[c]=pd.to_datetime(members[c],errors='raise')
    if (members.start_date>members.end_date).any():raise ValueError('成分股有效区间颠倒')
    if members[['security_id','company_id','start_date','end_date']].duplicated().any():raise ValueError('成分区间重复')
    caps['date']=pd.to_datetime(caps['date'],errors='raise')
    caps['market_cap']=pd.to_numeric(caps['market_cap'],errors='raise')
    if caps[['security_id','date']].duplicated().any():raise ValueError('市值有重复的证券日期')
    if (~np.isfinite(caps.market_cap)|(caps.market_cap<=0)).any():raise ValueError('市值必须为有限正数')
    earnings['announcement_date']=pd.to_datetime(earnings['announcement_date'],errors='raise')
    earnings=earnings.drop_duplicates(['company_id','announcement_date'])
    cal=pd.DatetimeIndex(pd.to_datetime(calendar)).sort_values()
    if cal.has_duplicates:raise ValueError('交易日历重复')
    start=pd.Timestamp(start);end=pd.Timestamp(end)
    target=cal[(cal>=start)&(cal<=end)]
    if not len(target):raise ValueError('目标样本为空')
    last=cal.get_loc(target[-1])+6
    if last>=len(cal):raise ValueError('缺少末端6个交易日历缓冲')
    required=cal[cal.get_loc(target[0]):last+1]
    members=members[(members.start_date<=required[-1])&(members.end_date>=required[0])]
    absent=set(members.company_id)-set(earnings.company_id)
    if absent:raise ValueError('有当期成分公司在财报源中完全没有记录，不能默认无公告：'+','.join(sorted(absent)[:15]))
    event_map=earnings.groupby('announcement_date')['company_id'].apply(set).to_dict()
    cap_index=caps.set_index(['date','security_id']).market_cap
    audit=[]
    for day in required:
        active=members[(members.start_date<=day)&(members.end_date>=day)]
        if active.security_id.duplicated().any():raise ValueError(f'{day.date()} 同一证券成分或公司映射区间重叠')
        if len(active)<min_securities:raise ValueError(f'{day.date()} 仅{len(active)}个证券，历史名单可能不完整')
        announced=event_map.get(day,set())
        keys=pd.MultiIndex.from_arrays([[day]*len(active),active.security_id])
        values=cap_index.reindex(keys)
        if values.isna().any():raise ValueError(f'{day.date()} 缺少当期证券市值，不能用0或删掉证券缩小分母')
        amounts=values.to_numpy(dtype=float)
        denominator=float(amounts.sum())
        numerator=float(amounts[active.company_id.isin(announced).to_numpy()].sum())
        audit.append(dict(date=day,member_securities=len(active),member_companies=active.company_id.nunique(),announcing_companies=len(set(active.company_id)&announced),announcing_market_cap=numerator,total_market_cap=denominator,ann_ratio=numerator/denominator))
    audit=pd.DataFrame(audit).set_index('date')
    threshold=float(audit.loc[target,'ann_ratio'].quantile(.95,interpolation='linear'))
    # This implementation is a strict >95th-percentile rule; document ties explicitly.
    high=audit.ann_ratio>threshold
    news=[]
    macro=macro.copy();macro['date']=pd.to_datetime(macro['date']);macro['mnews26']=pd.to_numeric(macro['mnews26'])
    if macro.date.duplicated().any() or not macro.mnews26.isin([0,1]).all():raise ValueError('Macro News 必须日期唯一且取0/1')
    m=macro.set_index('date').mnews26
    for day in target:
        if day not in m:raise ValueError('宏观窗口缺失：'+str(day.date()))
        i=cal.get_loc(day);future=cal[i+2:i+7]
        ann26=int(high.loc[future].any());flag=int(m.loc[day])
        news.append(dict(date=day,news26=max(flag,ann26),mnews26=flag,ann_26=ann26,window_start=future[0],window_end=future[-1]))
    return audit.reset_index(),pd.DataFrame(news),threshold

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--start',default='2010-02-01');parser.add_argument('--end',default='2019-10-04')
    parser.add_argument('--confirm-earnings-coverage',action='store_true',help='确认财报源覆盖当期所有成分公司；缺失记录不能当作无公告')
    args=parser.parse_args()
    if not args.confirm_earnings_coverage:raise ValueError('输入仍需核实完整历史财报覆盖；阅读README后，确认数据覆盖才能添加 --confirm-earnings-coverage')
    inp=HERE/'inputs'
    members=load(inp/'membership.csv',['security_id','company_id','start_date','end_date'])
    caps=load(inp/'daily_marketcap.csv',['date','security_id','market_cap'])
    earnings=load(inp/'earnings.csv',['announcement_date','company_id'])
    market=pd.read_csv(HERE.parent/'vwret_标普500替代/sp500d.csv',usecols=['caldt'])['caldt']
    macro=pd.read_csv(HERE.parent/'mnews26/mnews26.csv')
    audit,windows,cut=construct(members,caps,earnings,market,macro,args.start,args.end)
    audit.to_csv(HERE/'ann_ratio_audit.csv',index=False,date_format='%Y-%m-%d')
    windows.to_csv(HERE/'window_audit.csv',index=False,date_format='%Y-%m-%d')
    windows[['date','news26']].to_csv(HERE/'news26.csv',index=False,date_format='%Y-%m-%d')
    (HERE/'summary.json').write_text(json.dumps(dict(start=args.start,end=args.end,n=len(windows),news_rows=int(windows.news26.sum()),threshold=cut,scope='Historical S&P500 members, daily security market cap, issuer earnings events',quantile_rule='strictly greater than sample linear 95th percentile'),ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'已生成 news26.csv，共{len(windows)}行，市值占比95%分位数={cut:.8f}')

if __name__=='__main__':main()
