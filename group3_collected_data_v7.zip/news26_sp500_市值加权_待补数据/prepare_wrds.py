#!/usr/bin/env python3
"""Normalize four legacy-format WRDS exports; never log in or download licensed data."""
from pathlib import Path
import argparse
import pandas as pd
HERE=Path(__file__).resolve().parent

def main():
    p=argparse.ArgumentParser();p.add_argument('--start',default='2010-02-01');p.add_argument('--buffer-end',default='2019-10-14');args=p.parse_args()
    src=HERE/'wrds_exports';out=HERE/'inputs';out.mkdir(exist_ok=True)
    files={'members':['permno','start','ending'],'links':['lpermno','gvkey','linkdt','linkenddt','linktype','linkprim'],'stocks':['permno','date','prc','shrout'],'fundq':['gvkey','rdq']}
    data={}
    for n,cols in files.items():
        df=pd.read_csv(src/(n+'.csv'),dtype=str);df.columns=df.columns.str.lower()
        if set(cols)-set(df.columns):raise ValueError(f'{n}.csv 缺列：{set(cols)-set(df.columns)}；新版CRSP字段请按说明映射')
        data[n]=df
    start=pd.Timestamp(args.start);end=pd.Timestamp(args.buffer_end)
    m=data['members'];m['start']=pd.to_datetime(m.start);m['ending']=pd.to_datetime(m.ending,errors='coerce').fillna(end)
    m=m[(m.start<=end)&(m.ending>=start)].drop_duplicates(['permno','start','ending'])
    link=data['links'];link=link[link.linktype.isin(['LC','LU'])&link.linkprim.isin(['P','C'])].copy()
    link['linkdt']=pd.to_datetime(link.linkdt,errors='coerce').fillna(pd.Timestamp('1900-01-01'))
    link['linkenddt']=pd.to_datetime(link.linkenddt,errors='coerce').fillna(pd.Timestamp('2099-12-31'))
    joined=m.merge(link,left_on='permno',right_on='lpermno',how='left')
    joined['start_date']=joined[['start','linkdt']].max(axis=1).clip(lower=start)
    joined['end_date']=joined[['ending','linkenddt']].min(axis=1).clip(upper=end)
    joined=joined[(joined.start_date<=joined.end_date)&joined.gvkey.notna()].copy()
    # Every original constituent interval must be covered without inventing issuer IDs.
    for r in m.itertuples():
        lo=max(r.start,start);hi=min(r.ending,end);cursor=lo
        pieces=joined[(joined.permno==r.permno)&(joined.start_date<=hi)&(joined.end_date>=lo)].sort_values('start_date')
        for q in pieces.itertuples():
            if q.start_date>cursor:raise ValueError(f'PERMNO {r.permno} 存在公司映射缺口 {cursor.date()}；核查CCM链接')
            cursor=max(cursor,q.end_date+pd.Timedelta(days=1))
        if cursor<=hi:raise ValueError(f'PERMNO {r.permno} 未完整覆盖历史公司映射')
    members=joined.rename(columns={'permno':'security_id','gvkey':'company_id'})[['security_id','company_id','start_date','end_date']].drop_duplicates()
    members.to_csv(out/'membership.csv',index=False,date_format='%Y-%m-%d')
    stocks=data['stocks'];stocks['date']=pd.to_datetime(stocks.date);stocks=stocks[stocks.permno.isin(m.permno)&stocks.date.between(start,end)].copy()
    stocks['market_cap']=pd.to_numeric(stocks.prc,errors='coerce').abs()*pd.to_numeric(stocks.shrout,errors='coerce')*1000
    stocks.rename(columns={'permno':'security_id'})[['date','security_id','market_cap']].to_csv(out/'daily_marketcap.csv',index=False,date_format='%Y-%m-%d')
    e=data['fundq'];e['rdq']=pd.to_datetime(e.rdq,errors='coerce');e=e[e.gvkey.isin(members.company_id)&e.rdq.notna()].copy()
    e.rename(columns={'gvkey':'company_id','rdq':'announcement_date'})[['announcement_date','company_id']].drop_duplicates().to_csv(out/'earnings.csv',index=False,date_format='%Y-%m-%d')
    print('已生成三个标准输入；仍需核对成分区间、CCM映射和财报覆盖，再运行 build.py')

if __name__=='__main__':main()
